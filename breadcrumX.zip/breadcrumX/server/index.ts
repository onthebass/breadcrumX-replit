import express, { Request, Response, NextFunction } from 'express';
import { db } from './db';
import { assets, auditLogs, apiMetrics, usageEvents, attachments, userProfiles } from '../shared/schema';
import { eq, desc, sql, gte } from 'drizzle-orm';
import 'dotenv/config';

const app = express();
app.use(express.json({ limit: '50mb' }));

const PORT = 3001;
const startTime = Date.now();

const metricsMiddleware = async (req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  
  res.on('finish', async () => {
    const responseTime = Date.now() - start;
    const endpoint = req.route?.path || req.path;
    
    if (endpoint.startsWith('/api/') && !endpoint.includes('/metrics') && !endpoint.includes('/health')) {
      try {
        await db.insert(apiMetrics).values({
          endpoint,
          method: req.method,
          statusCode: res.statusCode,
          responseTime,
        });
      } catch (error) {
        console.error('Failed to log metric:', error);
      }
    }
  });
  
  next();
};

app.use(metricsMiddleware);

app.get('/api/assets', async (req, res) => {
  try {
    const allAssets = await db.select().from(assets).orderBy(assets.sortOrder, assets.createdAt);
    res.json(allAssets);
  } catch (error) {
    console.error('Error fetching assets:', error);
    res.status(500).json({ error: 'Failed to fetch assets' });
  }
});

app.post('/api/assets', async (req, res) => {
  try {
    const { assetId, name, category, type, value, region, expiryDate, policyNumber, encryptedPayload } = req.body;
    const [newAsset] = await db.insert(assets).values({
      assetId,
      name,
      category,
      type,
      value,
      region,
      expiryDate,
      policyNumber,
      encryptedPayload,
    }).returning();
    res.json(newAsset);
  } catch (error) {
    console.error('Error creating asset:', error);
    res.status(500).json({ error: 'Failed to create asset' });
  }
});

app.put('/api/assets/:assetId', async (req, res) => {
  try {
    const { assetId } = req.params;
    const { name, category, type, value, region, expiryDate, policyNumber, encryptedPayload } = req.body;
    const [updatedAsset] = await db.update(assets)
      .set({
        name,
        category,
        type,
        value,
        region,
        expiryDate,
        policyNumber,
        encryptedPayload,
        lastUpdated: new Date(),
      })
      .where(eq(assets.assetId, assetId))
      .returning();
    
    if (!updatedAsset) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    res.json(updatedAsset);
  } catch (error) {
    console.error('Error updating asset:', error);
    res.status(500).json({ error: 'Failed to update asset' });
  }
});

app.delete('/api/assets/:assetId', async (req, res) => {
  try {
    const { assetId } = req.params;
    const [deletedAsset] = await db.delete(assets)
      .where(eq(assets.assetId, assetId))
      .returning();
    
    if (!deletedAsset) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting asset:', error);
    res.status(500).json({ error: 'Failed to delete asset' });
  }
});

app.post('/api/assets/bulk', async (req, res) => {
  try {
    const assetsToCreate = req.body.assets;
    const newAssets = await db.insert(assets).values(assetsToCreate).returning();
    res.json(newAssets);
  } catch (error) {
    console.error('Error bulk creating assets:', error);
    res.status(500).json({ error: 'Failed to bulk create assets' });
  }
});

app.post('/api/assets/reorder', async (req, res) => {
  try {
    const { updates } = req.body;
    
    if (!updates || !Array.isArray(updates)) {
      return res.status(400).json({ error: 'Invalid updates array' });
    }
    
    const updatePromises = updates.map(({ assetId, sortOrder }: { assetId: string; sortOrder: number }) =>
      db.update(assets)
        .set({ sortOrder })
        .where(eq(assets.assetId, assetId))
    );
    
    await Promise.all(updatePromises);
    res.json({ success: true });
  } catch (error) {
    console.error('Error reordering assets:', error);
    res.status(500).json({ error: 'Failed to reorder assets' });
  }
});

app.get('/api/audit-logs', async (req, res) => {
  try {
    const logs = await db.select().from(auditLogs).orderBy(auditLogs.timestamp);
    res.json(logs);
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    res.status(500).json({ error: 'Failed to fetch audit logs' });
  }
});

app.post('/api/audit-logs', async (req, res) => {
  try {
    const { logId, action, details, type } = req.body;
    const [newLog] = await db.insert(auditLogs).values({
      logId,
      action,
      details,
      type,
    }).returning();
    res.json(newLog);
  } catch (error) {
    console.error('Error creating audit log:', error);
    res.status(500).json({ error: 'Failed to create audit log' });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    const dbCheck = await db.execute(sql`SELECT 1`);
    const uptime = Math.floor((Date.now() - startTime) / 1000);
    
    res.json({
      status: 'healthy',
      uptime,
      database: 'connected',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      database: 'disconnected',
      error: 'Database connection failed',
      timestamp: new Date().toISOString(),
    });
  }
});

app.get('/api/metrics/summary', async (req, res) => {
  try {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    
    const [totalAssets] = await db.select({ count: sql<number>`count(*)` }).from(assets);
    
    const recentMetrics = await db.select().from(apiMetrics)
      .where(gte(apiMetrics.timestamp, oneDayAgo))
      .orderBy(desc(apiMetrics.timestamp));
    
    const hourlyMetrics = recentMetrics.filter(m => 
      m.timestamp && new Date(m.timestamp) >= oneHourAgo
    );
    
    const totalRequests = recentMetrics.length;
    const errorCount = recentMetrics.filter(m => m.statusCode >= 400).length;
    const avgResponseTime = totalRequests > 0
      ? recentMetrics.reduce((sum, m) => sum + m.responseTime, 0) / totalRequests
      : 0;
    
    const endpointStats = recentMetrics.reduce((acc, m) => {
      const key = `${m.method} ${m.endpoint}`;
      if (!acc[key]) {
        acc[key] = { count: 0, totalTime: 0, errors: 0 };
      }
      acc[key].count++;
      acc[key].totalTime += m.responseTime;
      if (m.statusCode >= 400) acc[key].errors++;
      return acc;
    }, {} as Record<string, { count: number; totalTime: number; errors: number }>);
    
    const topEndpoints = Object.entries(endpointStats)
      .map(([endpoint, stats]) => ({
        endpoint,
        requests: stats.count,
        avgResponseTime: Math.round(stats.totalTime / stats.count),
        errorRate: Math.round((stats.errors / stats.count) * 100),
      }))
      .sort((a, b) => b.requests - a.requests)
      .slice(0, 10);
    
    res.json({
      period: '24h',
      totalAssets: totalAssets.count,
      requests: {
        total: totalRequests,
        lastHour: hourlyMetrics.length,
        errorCount,
        errorRate: totalRequests > 0 ? Math.round((errorCount / totalRequests) * 100) : 0,
      },
      performance: {
        avgResponseTime: Math.round(avgResponseTime),
        unit: 'ms',
      },
      topEndpoints,
      uptime: Math.floor((Date.now() - startTime) / 1000),
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error fetching metrics:', error);
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
});

app.post('/api/metrics/events', async (req, res) => {
  try {
    const { eventType, category, metadata } = req.body;
    
    if (!eventType) {
      return res.status(400).json({ error: 'eventType is required' });
    }
    
    const [event] = await db.insert(usageEvents).values({
      eventType,
      category,
      metadata: metadata ? JSON.stringify(metadata) : null,
    }).returning();
    
    res.json({ success: true, id: event.id });
  } catch (error) {
    console.error('Error logging event:', error);
    res.status(500).json({ error: 'Failed to log event' });
  }
});

app.get('/api/metrics/events', async (req, res) => {
  try {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    
    const events = await db.select().from(usageEvents)
      .where(gte(usageEvents.timestamp, oneDayAgo))
      .orderBy(desc(usageEvents.timestamp));
    
    const eventCounts = events.reduce((acc, e) => {
      acc[e.eventType] = (acc[e.eventType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    res.json({
      period: '24h',
      totalEvents: events.length,
      eventCounts,
      recentEvents: events.slice(0, 50),
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

app.get('/api/assets/:assetId/attachments', async (req, res) => {
  try {
    const { assetId } = req.params;
    const assetAttachments = await db.select({
      id: attachments.id,
      attachmentId: attachments.attachmentId,
      assetId: attachments.assetId,
      fileName: attachments.fileName,
      fileType: attachments.fileType,
      fileSize: attachments.fileSize,
      createdAt: attachments.createdAt,
    }).from(attachments)
      .where(eq(attachments.assetId, assetId))
      .orderBy(desc(attachments.createdAt));
    res.json(assetAttachments);
  } catch (error) {
    console.error('Error fetching attachments:', error);
    res.status(500).json({ error: 'Failed to fetch attachments' });
  }
});

app.post('/api/assets/:assetId/attachments', async (req, res) => {
  try {
    const { assetId } = req.params;
    const { fileName, fileType, fileSize, fileData } = req.body;
    
    if (!fileName || !fileData) {
      return res.status(400).json({ error: 'fileName and fileData are required' });
    }
    
    const MAX_FILE_SIZE = 10 * 1024 * 1024;
    if (fileSize && fileSize > MAX_FILE_SIZE) {
      return res.status(400).json({ error: 'File size must be less than 10MB' });
    }
    
    const [existingAsset] = await db.select().from(assets).where(eq(assets.assetId, assetId)).limit(1);
    if (!existingAsset) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    
    const generatedAttachmentId = `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const [newAttachment] = await db.insert(attachments).values({
      attachmentId: generatedAttachmentId,
      assetId,
      fileName,
      fileType: fileType || 'application/octet-stream',
      fileSize: fileSize || 0,
      fileData,
    }).returning();
    
    res.json({
      id: newAttachment.id,
      attachmentId: newAttachment.attachmentId,
      assetId: newAttachment.assetId,
      fileName: newAttachment.fileName,
      fileType: newAttachment.fileType,
      fileSize: newAttachment.fileSize,
      createdAt: newAttachment.createdAt,
    });
  } catch (error) {
    console.error('Error uploading attachment:', error);
    res.status(500).json({ error: 'Failed to upload attachment' });
  }
});

app.get('/api/attachments/:attachmentId/download', async (req, res) => {
  try {
    const { attachmentId } = req.params;
    const [attachment] = await db.select().from(attachments)
      .where(eq(attachments.attachmentId, attachmentId));
    
    if (!attachment) {
      return res.status(404).json({ error: 'Attachment not found' });
    }
    
    res.json({
      fileName: attachment.fileName,
      fileType: attachment.fileType,
      fileData: attachment.fileData,
    });
  } catch (error) {
    console.error('Error downloading attachment:', error);
    res.status(500).json({ error: 'Failed to download attachment' });
  }
});

app.delete('/api/attachments/:attachmentId', async (req, res) => {
  try {
    const { attachmentId } = req.params;
    const [deletedAttachment] = await db.delete(attachments)
      .where(eq(attachments.attachmentId, attachmentId))
      .returning();
    
    if (!deletedAttachment) {
      return res.status(404).json({ error: 'Attachment not found' });
    }
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting attachment:', error);
    res.status(500).json({ error: 'Failed to delete attachment' });
  }
});

app.get('/api/profile/:email', async (req, res) => {
  try {
    const { email } = req.params;
    const [profile] = await db.select().from(userProfiles)
      .where(eq(userProfiles.email, email));
    
    if (!profile) {
      return res.json({
        name: '',
        email,
        plan: 'Free',
        mfaEnabled: false,
        biometricEnabled: false,
        notifications: { email: true, push: false },
        avatar: { type: 'none', value: '' },
      });
    }
    
    res.json({
      name: profile.name,
      email: profile.email,
      plan: profile.plan,
      mfaEnabled: profile.mfaEnabled === 1,
      biometricEnabled: profile.biometricEnabled === 1,
      notifications: {
        email: profile.notifyEmail === 1,
        push: profile.notifyPush === 1,
      },
      avatar: {
        type: profile.avatarType as 'template' | 'upload' | 'none',
        value: profile.avatarValue || '',
      },
    });
  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

app.put('/api/profile/:email', async (req, res) => {
  try {
    const { email } = req.params;
    const { name, plan, mfaEnabled, biometricEnabled, notifications, avatar } = req.body;
    
    const [existingProfile] = await db.select().from(userProfiles)
      .where(eq(userProfiles.email, email));
    
    const profileData = {
      name: name || '',
      email,
      plan: plan || 'Free',
      mfaEnabled: mfaEnabled ? 1 : 0,
      biometricEnabled: biometricEnabled ? 1 : 0,
      notifyEmail: notifications?.email ? 1 : 0,
      notifyPush: notifications?.push ? 1 : 0,
      avatarType: avatar?.type || 'none',
      avatarValue: avatar?.value || '',
      updatedAt: new Date(),
    };
    
    let savedProfile;
    if (existingProfile) {
      [savedProfile] = await db.update(userProfiles)
        .set(profileData)
        .where(eq(userProfiles.email, email))
        .returning();
    } else {
      [savedProfile] = await db.insert(userProfiles)
        .values(profileData)
        .returning();
    }
    
    res.json({
      name: savedProfile.name,
      email: savedProfile.email,
      plan: savedProfile.plan,
      mfaEnabled: savedProfile.mfaEnabled === 1,
      biometricEnabled: savedProfile.biometricEnabled === 1,
      notifications: {
        email: savedProfile.notifyEmail === 1,
        push: savedProfile.notifyPush === 1,
      },
      avatar: {
        type: savedProfile.avatarType as 'template' | 'upload' | 'none',
        value: savedProfile.avatarValue || '',
      },
    });
  } catch (error) {
    console.error('Error saving profile:', error);
    res.status(500).json({ error: 'Failed to save profile' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
