import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Type, type FunctionDeclaration } from "@google/genai";
import { 
  DndContext, 
  closestCenter, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors,
  DragEndEvent
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { 
  Shield, Lock, Upload, FileText, CreditCard, HardDrive, 
  Archive, Plus, Fingerprint, Smartphone, Scan, 
  LogOut, AlertCircle, CheckCircle, Search, MapPin, LayoutGrid,
  MessageCircle, X, Download, FileSpreadsheet, FileType, Send, Bot,
  ChevronDown, Check, Sun, Moon, Trash2, Landmark, Link2, ShieldCheck, Building2, ChevronLeft, ArrowRight, Settings, FolderInput,
  Camera, ScanLine, UserPlus, RefreshCw, Watch, ArrowUpDown, GripVertical,
  User, Key, FileKey, Activity, Globe, Bell, Cpu, Mail, Calendar, CloudRain, Sparkles, Loader2,
  Heart, Scale, SearchX, FolderOpen, Edit3, Eye, History, Mic, Image as ImageIcon, Wand2, Folder, Paperclip, Star,
  HelpCircle, Lightbulb, MessageSquare, Zap
} from 'lucide-react';

// --- Types ---

type Region = 'AU' | 'US';
type CategoryType = 'Financial' | 'Physical' | 'Digital' | 'Medical' | 'Legal' | 'Personal';
type Theme = 'light' | 'dark';
type IngestionMode = 'document' | 'physical' | null;

interface Asset {
  id: string;
  name: string;
  type: string;
  category: CategoryType;
  region: Region;
  value?: string;
  expiryDate?: string; 
  lastUpdated?: string; 
  policyNumber?: string; 
  encryptedData: string; 
  legacyAction?: 'Memorialize' | 'Delete';
  sortOrder?: number;
}

interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: string;
  details: string;
  type: 'info' | 'warning' | 'security' | 'creation' | 'bulk_action';
}

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

interface Attachment {
  id: number;
  attachmentId: string;
  assetId: string;
  fileName: string;
  fileType: string | null;
  fileSize: number | null;
  createdAt: string | null;
}

interface UserProfile {
  name: string;
  email: string;
  plan: 'Free' | 'Sovereign' | 'Legacy';
  mfaEnabled: boolean;
  biometricEnabled: boolean;
  notifications: {
    email: boolean;
    push: boolean;
  };
  avatar: {
    type: 'template' | 'upload' | 'none';
    value: string;
  };
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

type HelpContext = 'dashboard' | 'category' | 'asset-entry' | 'auto-discovery' | 'settings' | 'audit' | 'general';

interface ContextualHelp {
  title: string;
  description: string;
  suggestions: string[];
}

const HELP_CONTEXTS: Record<HelpContext, ContextualHelp> = {
  dashboard: {
    title: 'Dashboard',
    description: "You're viewing your asset overview",
    suggestions: [
      'How do I add a new asset?',
      'What do the different categories mean?',
      'How can I search for specific assets?',
    ],
  },
  category: {
    title: 'Category View',
    description: "You're browsing assets in a specific category",
    suggestions: [
      'How do I move assets between categories?',
      'Can I bulk select and delete assets?',
      'How do I edit an existing asset?',
    ],
  },
  'asset-entry': {
    title: 'Adding an Asset',
    description: "You're creating a new asset entry",
    suggestions: [
      'How does AI-powered asset detection work?',
      'What file types can I upload?',
      'How do I use voice input?',
    ],
  },
  'auto-discovery': {
    title: 'Auto-Discovery',
    description: "You're using AI to discover assets",
    suggestions: [
      'How does auto-discovery find my assets?',
      'Is my data safe during scanning?',
      'What sources does it check?',
    ],
  },
  settings: {
    title: 'Settings',
    description: "You're managing your account settings",
    suggestions: [
      'How do I enable two-factor authentication?',
      'What does rotating my master key do?',
      'How do I change my notification preferences?',
    ],
  },
  audit: {
    title: 'Audit Log',
    description: "You're viewing security and activity logs",
    suggestions: [
      'What actions are logged?',
      'How long are logs kept?',
      'Can I export my audit history?',
    ],
  },
  general: {
    title: 'Help Center',
    description: 'Ask me anything about breadcrumX',
    suggestions: [
      'What is breadcrumX?',
      'How is my data protected?',
      'What are the different subscription plans?',
    ],
  },
};

const TEMPLATE_AVATARS = [
  { id: 'avatar-1', color: 'from-blue-400 to-blue-600', icon: 'user' },
  { id: 'avatar-2', color: 'from-purple-400 to-purple-600', icon: 'shield' },
  { id: 'avatar-3', color: 'from-teal-400 to-teal-600', icon: 'key' },
  { id: 'avatar-4', color: 'from-orange-400 to-orange-600', icon: 'star' },
  { id: 'avatar-5', color: 'from-pink-400 to-pink-600', icon: 'heart' },
  { id: 'avatar-6', color: 'from-green-400 to-green-600', icon: 'check' },
];

const DEFAULT_PROFILE: UserProfile = {
  name: '',
  email: 'user@gmail.com',
  plan: 'Free',
  mfaEnabled: false,
  biometricEnabled: false,
  notifications: { email: true, push: false },
  avatar: { type: 'none', value: '' },
};

// --- Constants ---

const CATEGORY_LABELS: Record<CategoryType, string> = {
  Financial: 'Financial Assets',
  Physical: 'Physical Assets',
  Digital: 'Digital Assets',
  Medical: 'Medical Information',
  Legal: 'Legal Documentation',
  Personal: 'Personal / Other'
};

// --- Utilities ---

const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const trackEvent = async (eventType: string, category?: string, metadata?: Record<string, any>) => {
  try {
    await fetch('/api/metrics/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ eventType, category, metadata }),
    });
  } catch (error) {
    console.debug('Event tracking failed:', error);
  }
};

const parseNumericValue = (value: string): string => {
  const cleaned = value.replace(/[^0-9.]/g, '');
  const parts = cleaned.split('.');
  if (parts.length > 2) {
    return parts[0] + '.' + parts.slice(1).join('');
  }
  return cleaned;
};

const formatCurrencyValue = (value: string): string => {
  if (!value) return '';
  const numericValue = parseNumericValue(value);
  if (!numericValue) return '';
  const parts = numericValue.split('.');
  const integerPart = parts[0];
  const decimalPart = parts[1];
  const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  if (decimalPart !== undefined) {
    return `$${formattedInteger}.${decimalPart}`;
  }
  return `$${formattedInteger}`;
};

const handleCurrencyInput = (
  e: React.ChangeEvent<HTMLInputElement>,
  setFormData: (updater: (prev: any) => any) => void
) => {
  const input = e.target.value;
  const cursorPosition = e.target.selectionStart || 0;
  const previousLength = e.target.value.length;
  const numericValue = parseNumericValue(input);
  const formattedValue = formatCurrencyValue(numericValue);
  setFormData((prev: any) => ({ ...prev, value: formattedValue }));
};

// --- Mock Crypto Service ---
const CryptoService = {
  deriveKey: async (pin: string, salt: string) => {
    await new Promise(resolve => setTimeout(resolve, 800)); 
    return `key-${pin}-${salt}`;
  },
  encrypt: (data: any, key: string) => {
    return `ENC[${btoa(JSON.stringify(data))}]::KEY[${key.substring(0, 5)}...]`;
  },
  decrypt: async (cipher: string, key: string) => {
    await new Promise(resolve => setTimeout(resolve, 5)); 
    return cipher; 
  }
};

// --- Components ---

const ThemeToggle = ({ theme, toggleTheme }: { theme: Theme, toggleTheme: () => void }) => (
  <button 
    onClick={toggleTheme} 
    className="p-2 rounded-full bg-slate-200 dark:bg-navy-700 text-slate-600 dark:text-mint-400 hover:bg-slate-300 dark:hover:bg-navy-600 transition-all focus:outline-none focus:ring-2 focus:ring-teal-500 dark:focus:ring-mint-400"
    aria-label="Toggle Theme"
  >
    {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
  </button>
);

// 1. Authentication Flow
const AuthFlow = ({ 
  onComplete, 
  theme, 
  toggleTheme 
}: { 
  onComplete: (pin: string) => void,
  theme: Theme, 
  toggleTheme: () => void 
}) => {
  const [loading, setLoading] = useState(false);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-slate-50 dark:bg-navy-900 transition-colors duration-300 relative">
      <div className="absolute top-4 right-4">
        <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
      </div>
      <div className="mb-8 text-center">
        <Shield className="w-16 h-16 text-teal-600 dark:text-mint-400 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-slate-900 dark:text-gray-100">breadcrumX</h1>
        <p className="text-teal-600 dark:text-mint-400 tracking-widest text-sm mt-2 uppercase">The Invisible Fortress</p>
      </div>
      <div className="bg-white dark:bg-navy-700 p-8 rounded-xl border border-slate-200 dark:border-navy-600 shadow-2xl max-w-md w-full text-center transition-colors duration-300">
        <div className="bg-teal-50 dark:bg-mint-400/10 border border-teal-100 dark:border-mint-400/20 rounded p-3 mb-6">
          <p className="text-teal-600 dark:text-mint-400 text-xs font-mono uppercase tracking-wider">Tester Access Enabled</p>
        </div>
        
        <h2 className="text-xl text-slate-800 dark:text-gray-200 mb-2">Developer Preview</h2>
        <p className="text-sm text-slate-500 dark:text-gray-400 mb-8">
          Security protocols (OAuth, MFA, Biometrics) have been temporarily bypassed for testing purposes.
        </p>
        
        <button 
          onClick={async () => {
            setLoading(true);
            setTimeout(() => onComplete('0000'), 500);
          }}
          disabled={loading}
          className="w-full bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 font-bold py-3 px-4 rounded hover:bg-teal-600 dark:hover:bg-mint-300 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Deriving Mock Keys...
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              Enter Vault
            </>
          )}
        </button>
      </div>
    </div>
  );
};

// 2. Comprehensive Asset Entry Modal (AI + Manual + Voice)
const AssetEntryModal = ({ 
  isOpen, 
  onClose, 
  onSave,
  defaultCategory
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onSave: (asset: Omit<Asset, 'id'>) => void,
  defaultCategory?: CategoryType
}) => {
  const [loading, setLoading] = useState(false);
  const [magicText, setMagicText] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({
    name: '',
    category: (defaultCategory || 'Personal') as CategoryType,
    type: '',
    region: 'US' as Region,
    value: '',
    expiryDate: '',
    policyNumber: '',
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && defaultCategory) {
      setFormData(prev => ({ ...prev, category: defaultCategory }));
    }
  }, [isOpen, defaultCategory]);

  if (!isOpen) return null;

  const handleAIProcess = async (sourceType: 'image' | 'text', payload: any) => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const prompt = `
        Analyze the input and extract structured asset data.
        Return JSON with fields:
        - name (string)
        - type (string, e.g. "Watch", "Contract", "Vehicle")
        - category (one of: Financial, Physical, Digital, Medical, Legal, Personal)
        - value (string, estimated value with currency)
        - region (US or AU, infer from context if possible, default US)
        - expiryDate (YYYY-MM-DD if applicable)
        - policyNumber (if applicable)
      `;

      let contents;
      if (sourceType === 'image') {
        contents = {
          parts: [
            { inlineData: { mimeType: payload.mimeType, data: payload.data } },
            { text: prompt }
          ]
        };
      } else {
        contents = {
          parts: [{ text: `Input Text: "${payload}". ${prompt}` }]
        };
      }

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
             type: Type.OBJECT,
             properties: {
               name: { type: Type.STRING },
               type: { type: Type.STRING },
               category: { type: Type.STRING, enum: ["Financial", "Physical", "Digital", "Medical", "Legal", "Personal"] },
               value: { type: Type.STRING },
               region: { type: Type.STRING, enum: ["US", "AU"] },
               expiryDate: { type: Type.STRING },
               policyNumber: { type: Type.STRING }
             }
          }
        }
      });

      const result = JSON.parse(response.text || '{}');
      setFormData(prev => ({ ...prev, ...result }));
    } catch (e) {
      console.error("AI Processing Error", e);
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setPreviewImage(reader.result as string);
        handleAIProcess('image', { mimeType: file.type, data: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMagicText = () => {
    if (!magicText.trim()) return;
    handleAIProcess('text', magicText);
  };

  const toggleListening = () => {
    if ('webkitSpeechRecognition' in window) {
      if (isListening) return; // Already listening
      
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      
      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setMagicText(prev => (prev ? prev + ' ' : '') + text);
      };
      
      recognition.start();
    } else {
      alert("Voice input not supported in this browser.");
    }
  };

  const handleSave = () => {
    onSave({
      ...formData,
      lastUpdated: new Date().toISOString(),
      encryptedData: "SECURE_ENCRYPTED_PAYLOAD" 
    });
    onClose();
    // Reset state
    setFormData({ name: '', category: 'Personal', type: '', region: 'US', value: '', expiryDate: '', policyNumber: '' });
    setMagicText('');
    setPreviewImage(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 dark:bg-navy-900/90 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-navy-800 w-full max-w-3xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-900 flex justify-between items-center">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Plus className="w-5 h-5 text-teal-500" /> New Asset Entry
          </h2>
          <button onClick={onClose}><X className="w-5 h-5 text-slate-400 hover:text-slate-600" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          
          {/* AI Helper Section */}
          <div className="bg-teal-50 dark:bg-mint-400/10 rounded-xl p-5 mb-8 border border-teal-100 dark:border-mint-400/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Sparkles className="w-24 h-24 text-teal-600 dark:text-mint-400" />
            </div>
            
            <h3 className="text-sm font-bold text-teal-900 dark:text-mint-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Smart Auto-Fill
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Option A: Upload/Photo */}
              <div className="space-y-3">
                 <p className="text-sm text-slate-600 dark:text-gray-300 font-medium">From Document or Photo</p>
                 <div className="flex gap-2">
                   <button 
                     onClick={() => fileInputRef.current?.click()}
                     className="flex-1 bg-white dark:bg-navy-800 border border-slate-200 dark:border-navy-600 hover:border-teal-500 dark:hover:border-mint-400 text-slate-700 dark:text-gray-200 py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-sm group"
                   >
                     <ImageIcon className="w-4 h-4 group-hover:text-teal-500 dark:group-hover:text-mint-400" /> Upload
                   </button>
                   <button 
                     onClick={() => fileInputRef.current?.click()} 
                     className="flex-1 bg-white dark:bg-navy-800 border border-slate-200 dark:border-navy-600 hover:border-teal-500 dark:hover:border-mint-400 text-slate-700 dark:text-gray-200 py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-sm group"
                   >
                     <Camera className="w-4 h-4 group-hover:text-teal-500 dark:group-hover:text-mint-400" /> Photo
                   </button>
                   <input type="file" ref={fileInputRef} className="hidden" accept="image/*,.pdf" onChange={handleFileSelect} />
                 </div>
                 {previewImage && (
                   <div className="relative h-24 w-full rounded-lg overflow-hidden border border-slate-200 dark:border-navy-600">
                     <img src={previewImage} alt="Preview" className="w-full h-full object-cover opacity-50" />
                     <div className="absolute inset-0 flex items-center justify-center">
                       <CheckCircle className="w-8 h-8 text-teal-500 bg-white rounded-full" />
                     </div>
                   </div>
                 )}
              </div>

              {/* Option B: Manual/Voice Text */}
              <div className="space-y-3">
                 <p className="text-sm text-slate-600 dark:text-gray-300 font-medium">Magic Description</p>
                 <div className="relative">
                   <textarea 
                     value={magicText}
                     onChange={(e) => setMagicText(e.target.value)}
                     placeholder="e.g. 'I have a vintage Rolex Submariner worth about $8,000 bought in 2018.'"
                     className="w-full h-[100px] p-3 pr-10 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-sm focus:ring-2 focus:ring-teal-500 outline-none resize-none"
                   />
                   <button
                     onClick={toggleListening}
                     className={`absolute right-3 top-3 w-6 h-6 rounded-full flex items-center justify-center transition-colors ${isListening ? 'bg-red-500 text-white animate-pulse' : 'text-slate-400 hover:text-teal-500'}`}
                     title="Use Voice Input"
                   >
                     <Mic className="w-4 h-4" />
                   </button>
                   <button 
                     onClick={handleMagicText}
                     disabled={!magicText || loading}
                     className="absolute right-2 bottom-2 bg-slate-900 dark:bg-white text-white dark:text-navy-900 text-xs font-bold px-3 py-1.5 rounded-md flex items-center gap-1 hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors disabled:opacity-50"
                   >
                     <Wand2 className="w-3 h-3" /> Fill
                   </button>
                 </div>
              </div>
            </div>

            {loading && (
              <div className="absolute inset-0 bg-white/50 dark:bg-navy-900/50 backdrop-blur-sm flex items-center justify-center rounded-xl z-10">
                <div className="bg-white dark:bg-navy-800 p-4 rounded-xl shadow-xl flex items-center gap-3 border border-slate-200 dark:border-navy-600">
                  <Loader2 className="w-5 h-5 animate-spin text-teal-500" />
                  <span className="font-bold text-sm text-slate-700 dark:text-white">Analyzing with Gemini...</span>
                </div>
              </div>
            )}
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Asset Name</label>
              <input 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none font-medium"
                placeholder="Name of asset"
              />
            </div>
            
            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Category</label>
              <select 
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value as CategoryType})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
              >
                {Object.keys(CATEGORY_LABELS).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Type / Sub-Category</label>
              <input 
                value={formData.type}
                onChange={(e) => setFormData({...formData, type: e.target.value})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                placeholder="e.g. Vehicle, Watch, Stock"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Estimated Value</label>
              <input 
                value={formData.value || ''}
                onChange={(e) => {
                  const formatted = formatCurrencyValue(e.target.value);
                  setFormData({...formData, value: formatted});
                }}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                placeholder="$0.00"
              />
            </div>

             <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Expiry Date</label>
              <input 
                type="date"
                value={formData.expiryDate || ''}
                onChange={(e) => setFormData({...formData, expiryDate: e.target.value})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-900 flex justify-end gap-3">
           <button onClick={onClose} className="px-6 py-3 rounded-lg font-bold text-slate-500 hover:text-slate-800 dark:text-gray-400 dark:hover:text-white transition-colors">
             Cancel
           </button>
           <button 
             onClick={handleSave}
             disabled={!formData.name || loading}
             className="px-8 py-3 rounded-lg font-bold bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 hover:bg-teal-600 dark:hover:bg-mint-300 transition-all shadow-lg disabled:opacity-50 disabled:shadow-none"
           >
             Save Asset
           </button>
        </div>
      </div>
    </div>
  );
};

// 2b. Edit Asset Modal
const EditAssetModal = ({
  asset,
  isOpen,
  onClose,
  onSave,
  onDelete,
  showToast
}: {
  asset: Asset | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (asset: Asset) => void;
  onDelete: (id: string) => void;
  showToast: (message: string, type: Toast['type']) => void;
}) => {
  const [formData, setFormData] = useState<Asset | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [loadingAttachments, setLoadingAttachments] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [viewingAttachment, setViewingAttachment] = useState<{ fileName: string; fileType: string; fileData: string } | null>(null);
  const [attachmentToDelete, setAttachmentToDelete] = useState<Attachment | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (asset && isOpen) {
      setFormData({ 
        ...asset,
        value: asset.value ? formatCurrencyValue(asset.value) : ''
      });
      setShowDeleteConfirm(false);
      setAttachmentToDelete(null);
      fetchAttachments(asset.id);
    }
  }, [asset, isOpen]);

  const fetchAttachments = async (assetId: string) => {
    setLoadingAttachments(true);
    try {
      const response = await fetch(`/api/assets/${assetId}/attachments`);
      if (response.ok) {
        const data = await response.json();
        setAttachments(data);
      }
    } catch (error) {
      console.error('Error fetching attachments:', error);
    } finally {
      setLoadingAttachments(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !formData) return;

    if (file.size > 10 * 1024 * 1024) {
      showToast('File size must be less than 10MB', 'error');
      return;
    }

    setUploadingFile(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const response = await fetch(`/api/assets/${formData.id}/attachments`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            fileType: file.type,
            fileSize: file.size,
            fileData: base64Data,
          }),
        });

        if (response.ok) {
          const newAttachment = await response.json();
          setAttachments(prev => [newAttachment, ...prev]);
          showToast('File attached successfully', 'success');
        } else {
          const errorData = await response.json();
          showToast(errorData.error || 'Failed to upload file', 'error');
        }
        setUploadingFile(false);
      };
      reader.onerror = () => {
        showToast('Failed to read file', 'error');
        setUploadingFile(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading file:', error);
      showToast('Failed to upload file', 'error');
      setUploadingFile(false);
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleViewAttachment = async (attachment: Attachment) => {
    try {
      const response = await fetch(`/api/attachments/${attachment.attachmentId}/download`);
      if (response.ok) {
        const data = await response.json();
        setViewingAttachment(data);
      } else {
        showToast('Failed to load file', 'error');
      }
    } catch (error) {
      console.error('Error viewing attachment:', error);
      showToast('Failed to load file', 'error');
    }
  };

  const handleDownloadAttachment = async (attachment: Attachment) => {
    try {
      const response = await fetch(`/api/attachments/${attachment.attachmentId}/download`);
      if (response.ok) {
        const data = await response.json();
        const link = document.createElement('a');
        link.href = data.fileData;
        link.download = data.fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        showToast('Download started', 'success');
      } else {
        showToast('Failed to download file', 'error');
      }
    } catch (error) {
      console.error('Error downloading attachment:', error);
      showToast('Failed to download file', 'error');
    }
  };

  const handleDeleteAttachment = (attachment: Attachment) => {
    setAttachmentToDelete(attachment);
  };

  const confirmDeleteAttachment = async () => {
    if (!attachmentToDelete) return;
    try {
      const response = await fetch(`/api/attachments/${attachmentToDelete.attachmentId}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        setAttachments(prev => prev.filter(a => a.attachmentId !== attachmentToDelete.attachmentId));
        showToast('Attachment deleted', 'success');
      } else {
        showToast('Failed to delete attachment', 'error');
      }
    } catch (error) {
      console.error('Error deleting attachment:', error);
      showToast('Failed to delete attachment', 'error');
    } finally {
      setAttachmentToDelete(null);
    }
  };

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return 'Unknown size';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getFileIcon = (fileType: string | null) => {
    if (!fileType) return FileText;
    if (fileType.startsWith('image/')) return ImageIcon;
    if (fileType.includes('pdf')) return FileText;
    if (fileType.includes('spreadsheet') || fileType.includes('excel')) return FileSpreadsheet;
    return FileType;
  };

  if (!isOpen || !formData) return null;

  const handleSave = () => {
    if (formData.name) {
      onSave(formData);
    }
  };

  const handleDelete = () => {
    onDelete(formData.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 dark:bg-navy-900/90 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-navy-800 border border-slate-200 dark:border-navy-600 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden transition-colors duration-300">
        <div className="bg-gradient-to-r from-slate-700 to-slate-800 dark:from-navy-700 dark:to-navy-800 p-6 text-white">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <Edit3 className="w-6 h-6" />
                 <div>
                   <h2 className="text-xl font-bold leading-none">Edit Asset</h2>
                   <p className="text-xs opacity-75 mt-1">Modify details or move to another category</p>
                 </div>
              </div>
              <button onClick={onClose}><X className="w-5 h-5" /></button>
           </div>
        </div>

        <div className="p-6 max-h-[60vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Asset Name</label>
              <input 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none font-medium"
                placeholder="Name of asset"
              />
            </div>
            
            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Category</label>
              <select 
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value as CategoryType})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
              >
                {Object.keys(CATEGORY_LABELS).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Type / Sub-Category</label>
              <input 
                value={formData.type}
                onChange={(e) => setFormData({...formData, type: e.target.value})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                placeholder="e.g. Vehicle, Watch, Stock"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Estimated Value</label>
              <input 
                value={formData.value || ''}
                onChange={(e) => {
                  const formatted = formatCurrencyValue(e.target.value);
                  setFormData({...formData, value: formatted});
                }}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                placeholder="$0.00"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Expiry Date</label>
              <input 
                type="date"
                value={formData.expiryDate || ''}
                onChange={(e) => setFormData({...formData, expiryDate: e.target.value})}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

          </div>

          {/* Attachments Section */}
          <div className="mt-6 pt-6 border-t border-slate-200 dark:border-navy-700">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Paperclip className="w-4 h-4 text-slate-500 dark:text-gray-400" />
                <label className="text-xs font-bold text-slate-500 dark:text-gray-400 uppercase">Attachments</label>
                {attachments.length > 0 && (
                  <span className="text-xs bg-slate-200 dark:bg-navy-600 text-slate-600 dark:text-gray-300 px-2 py-0.5 rounded-full">
                    {attachments.length}
                  </span>
                )}
              </div>
              <label className="cursor-pointer">
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                  disabled={uploadingFile}
                />
                <span className="flex items-center gap-1.5 text-sm text-teal-600 dark:text-mint-400 hover:text-teal-700 dark:hover:text-mint-300 font-medium transition-colors">
                  {uploadingFile ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Uploading...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" /> Add File
                    </>
                  )}
                </span>
              </label>
            </div>

            {loadingAttachments ? (
              <div className="flex items-center justify-center py-6">
                <Loader2 className="w-5 h-5 text-slate-400 animate-spin" />
              </div>
            ) : attachments.length === 0 ? (
              <div className="text-center py-6 bg-slate-50 dark:bg-navy-900/50 rounded-lg border border-dashed border-slate-200 dark:border-navy-600">
                <Paperclip className="w-8 h-8 text-slate-300 dark:text-navy-600 mx-auto mb-2" />
                <p className="text-sm text-slate-400 dark:text-gray-500">No files attached</p>
                <p className="text-xs text-slate-400 dark:text-gray-600 mt-1">Click "Add File" to attach documents</p>
              </div>
            ) : (
              <div className="space-y-2">
                {attachments.map((attachment) => {
                  const FileIcon = getFileIcon(attachment.fileType);
                  return (
                    <div 
                      key={attachment.attachmentId}
                      className="flex items-center justify-between p-3 bg-slate-50 dark:bg-navy-900/50 rounded-lg border border-slate-200 dark:border-navy-600 hover:border-slate-300 dark:hover:border-navy-500 transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="p-2 bg-slate-200 dark:bg-navy-700 rounded">
                          <FileIcon className="w-4 h-4 text-slate-600 dark:text-gray-400" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-slate-700 dark:text-gray-200 truncate">{attachment.fileName}</p>
                          <p className="text-xs text-slate-400 dark:text-gray-500">{formatFileSize(attachment.fileSize)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleViewAttachment(attachment)}
                          className="p-2 text-slate-400 hover:text-teal-600 dark:text-gray-500 dark:hover:text-mint-400 transition-colors"
                          title="View"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDownloadAttachment(attachment)}
                          className="p-2 text-slate-400 hover:text-teal-600 dark:text-gray-500 dark:hover:text-mint-400 transition-colors"
                          title="Download"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteAttachment(attachment)}
                          className="p-2 text-slate-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Delete Section */}
          <div className="mt-8 pt-6 border-t border-slate-200 dark:border-navy-700">
            {!showDeleteConfirm ? (
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center gap-2 text-red-500 hover:text-red-600 text-sm font-medium transition-colors"
              >
                <Trash2 className="w-4 h-4" /> Delete this asset
              </button>
            ) : (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                <p className="text-sm text-red-700 dark:text-red-300 mb-3">
                  Are you sure you want to permanently delete "{formData.name}"? This action cannot be undone.
                </p>
                <div className="flex gap-2">
                  <button 
                    onClick={handleDelete}
                    className="px-4 py-2 bg-red-600 text-white text-sm font-bold rounded hover:bg-red-700 transition-colors"
                  >
                    Yes, Delete
                  </button>
                  <button 
                    onClick={() => setShowDeleteConfirm(false)}
                    className="px-4 py-2 text-slate-600 dark:text-gray-400 text-sm font-medium hover:text-slate-800 dark:hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-900 flex justify-end gap-3">
           <button onClick={onClose} className="px-6 py-3 rounded-lg font-bold text-slate-500 hover:text-slate-800 dark:text-gray-400 dark:hover:text-white transition-colors">
             Cancel
           </button>
           <button 
             onClick={handleSave}
             disabled={!formData.name}
             className="px-8 py-3 rounded-lg font-bold bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 hover:bg-teal-600 dark:hover:bg-mint-300 transition-all shadow-lg disabled:opacity-50 disabled:shadow-none"
           >
             Save Changes
           </button>
        </div>
      </div>

      {/* Attachment Viewer Modal */}
      {viewingAttachment && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-navy-800 rounded-xl shadow-2xl max-w-4xl max-h-[90vh] w-full overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-navy-700">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-slate-500 dark:text-gray-400" />
                <span className="font-medium text-slate-800 dark:text-white">{viewingAttachment.fileName}</span>
              </div>
              <button 
                onClick={() => setViewingAttachment(null)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-navy-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-slate-500 dark:text-gray-400" />
              </button>
            </div>
            <div className="p-4 overflow-auto max-h-[calc(90vh-80px)]">
              {viewingAttachment.fileType?.startsWith('image/') ? (
                <img 
                  src={viewingAttachment.fileData} 
                  alt={viewingAttachment.fileName}
                  className="max-w-full h-auto mx-auto rounded-lg"
                />
              ) : viewingAttachment.fileType === 'application/pdf' ? (
                <object
                  data={viewingAttachment.fileData}
                  type="application/pdf"
                  className="w-full h-[70vh] rounded-lg"
                >
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-slate-300 dark:text-navy-600 mx-auto mb-4" />
                    <p className="text-slate-600 dark:text-gray-400 mb-4">PDF preview not supported in this browser</p>
                    <button
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = viewingAttachment.fileData;
                        link.download = viewingAttachment.fileName;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                      }}
                      className="px-4 py-2 bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 rounded-lg font-medium hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors"
                    >
                      <Download className="w-4 h-4 inline mr-2" />
                      Download PDF
                    </button>
                  </div>
                </object>
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 text-slate-300 dark:text-navy-600 mx-auto mb-4" />
                  <p className="text-slate-600 dark:text-gray-400 mb-4">Preview not available for this file type</p>
                  <button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = viewingAttachment.fileData;
                      link.download = viewingAttachment.fileName;
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                    className="px-4 py-2 bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 rounded-lg font-medium hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors"
                  >
                    <Download className="w-4 h-4 inline mr-2" />
                    Download File
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Attachment Delete Confirmation Modal */}
      {attachmentToDelete && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-navy-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-full">
                  <Trash2 className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white">Delete Attachment</h3>
              </div>
              <p className="text-sm text-slate-600 dark:text-gray-300 mb-6">
                Are you sure you want to permanently delete "{attachmentToDelete.fileName}"? This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={confirmDeleteAttachment}
                  className="flex-1 px-4 py-2 bg-red-600 text-white text-sm font-bold rounded-lg hover:bg-red-700 transition-colors"
                >
                  Yes, Delete
                </button>
                <button 
                  onClick={() => setAttachmentToDelete(null)}
                  className="flex-1 px-4 py-2 text-slate-600 dark:text-gray-400 text-sm font-medium hover:text-slate-800 dark:hover:text-white border border-slate-200 dark:border-navy-600 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 3. Auto-Discovery Modal
const AutoDiscoveryModal = ({
  isOpen,
  onClose,
  onImport
}: {
  isOpen: boolean;
  onClose: () => void;
  onImport: (assets: Omit<Asset, 'id'>[]) => void;
}) => {
  const [step, setStep] = useState<'select' | 'connecting' | 'scanning' | 'results'>('select');
  const [selectedSources, setSelectedSources] = useState<string[]>([]);
  const [foundAssets, setFoundAssets] = useState<any[]>([]);
  const [reviewingAsset, setReviewingAsset] = useState<any | null>(null);
  const [selectedAssetIndices, setSelectedAssetIndices] = useState<number[]>([]);
  
  const sources = [
    { id: 'gmail', label: 'Gmail', icon: Mail, desc: 'Receipts, Policies, Statements' },
    { id: 'drive', label: 'Google Drive', icon: CloudRain, desc: 'PDFs, Deeds, Contracts' },
    { id: 'calendar', label: 'Calendar', icon: Calendar, desc: 'Recurring Appointments' },
  ];

  useEffect(() => {
    if (!isOpen) {
       setStep('select');
       setSelectedSources([]);
       setFoundAssets([]);
       setReviewingAsset(null);
       setSelectedAssetIndices([]);
    }
  }, [isOpen]);

  const toggleAssetSelection = (idx: number) => {
    setSelectedAssetIndices(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  const toggleSelectAll = () => {
    if (selectedAssetIndices.length === foundAssets.length) {
      setSelectedAssetIndices([]);
    } else {
      setSelectedAssetIndices(foundAssets.map((_, idx) => idx));
    }
  };

  const toggleSource = (id: string) => {
    if (selectedSources.includes(id)) {
      setSelectedSources(prev => prev.filter(s => s !== id));
    } else {
      setSelectedSources(prev => [...prev, id]);
    }
  };

  const runDiscovery = async () => {
    if (selectedSources.length === 0) return;
    setStep('connecting');
    await new Promise(resolve => setTimeout(resolve, 1200));
    setStep('scanning');
    await new Promise(resolve => setTimeout(resolve, 2000));

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const prompt = `
        Generate 3 realistic "discovered" assets that might be found in a user's ${selectedSources.join(' and ')}.
        Return JSON:
        [
          { 
            "name": "string", 
            "type": "string", 
            "category": "Financial/Physical/Digital/Medical/Legal/Personal", 
            "source": "Gmail/Drive", 
            "value": "string",
            "snippet": "A short 1-sentence snippet of the email body or file text." 
          }
        ]
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                type: { type: Type.STRING },
                category: { type: Type.STRING },
                source: { type: Type.STRING },
                value: { type: Type.STRING },
                snippet: { type: Type.STRING }
              }
            }
          }
        }
      });
      setFoundAssets(JSON.parse(response.text || '[]'));
      setStep('results');
    } catch (e) {
      setFoundAssets([
        { name: "Old 401(k) - Fidelity", type: "Investment", category: "Financial", source: "Gmail", value: "$14,250", snippet: "Subject: Your Quarterly Statement." },
        { name: "Term Life Policy", type: "Insurance", category: "Legal", source: "Drive", value: "$500k Coverage", snippet: "File: Policy_73829.pdf." },
      ]);
      setStep('results');
    }
  };

  const updateAsset = (idx: number, updated: any) => {
    const newAssets = [...foundAssets];
    newAssets[idx] = updated;
    setFoundAssets(newAssets);
    setReviewingAsset(null);
  };

  const handleImport = () => {
    if (selectedAssetIndices.length === 0) return;
    const assetsToImport = selectedAssetIndices.map(idx => foundAssets[idx]);
    const mappedAssets = assetsToImport.map(a => ({
      name: a.name,
      type: a.type,
      category: a.category as CategoryType,
      region: 'US' as Region,
      value: a.value,
      lastUpdated: new Date().toISOString(),
      encryptedData: `ENC[IMPORTED_FROM_${a.source.toUpperCase()}]...`
    }));
    onImport(mappedAssets);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 dark:bg-navy-900/90 backdrop-blur-sm">
      <div className="bg-white dark:bg-navy-800 border border-slate-200 dark:border-navy-600 w-full max-w-xl rounded-xl shadow-2xl overflow-hidden transition-colors duration-300">
        <div className="bg-gradient-to-r from-teal-500 to-teal-600 dark:from-mint-400 dark:to-mint-500 p-6 text-white dark:text-navy-900">
           <div className="flex items-center justify-between">
             <div className="flex items-center gap-3">
                <Sparkles className="w-6 h-6" />
                <div>
                  <h2 className="text-xl font-bold leading-none">Auto-Discovery</h2>
                  <p className="text-xs opacity-90 mt-1">Powered by Gmail API</p>
                </div>
             </div>
             <button onClick={onClose}><X className="w-5 h-5" /></button>
           </div>
        </div>

        <div className="p-6">
          {step === 'select' && (
            <>
               <p className="text-slate-600 dark:text-gray-300 mb-4 text-sm">
                  Connect your Google account to scan for hidden assets.
               </p>
               <div className="space-y-3 mb-8">
                  {sources.map(source => {
                    const isSelected = selectedSources.includes(source.id);
                    const Icon = source.icon;
                    return (
                      <div 
                        key={source.id}
                        onClick={() => toggleSource(source.id)}
                        className={`flex items-center gap-4 p-4 rounded-lg border cursor-pointer transition-all ${
                           isSelected 
                             ? 'bg-teal-50 border-teal-500 dark:bg-mint-400/10 dark:border-mint-400' 
                             : 'border-slate-200 dark:border-navy-600 hover:bg-slate-50 dark:hover:bg-navy-700'
                        }`}
                      >
                         <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isSelected ? 'bg-teal-500 text-white dark:bg-mint-400 dark:text-navy-900' : 'bg-slate-100 text-slate-500 dark:bg-navy-900 dark:text-gray-400'}`}>
                            <Icon className="w-5 h-5" />
                         </div>
                         <div className="flex-1">
                            <h3 className="font-bold text-slate-900 dark:text-white">{source.label}</h3>
                            <p className="text-xs text-slate-500 dark:text-gray-400">{source.desc}</p>
                         </div>
                         {isSelected && <CheckCircle className="w-5 h-5 text-teal-600 dark:text-mint-400" />}
                      </div>
                    );
                  })}
               </div>
               <div className="flex justify-end gap-3">
                  <button onClick={onClose} className="px-4 py-2 text-slate-500 hover:text-slate-700">Cancel</button>
                  <button 
                    onClick={runDiscovery}
                    disabled={selectedSources.length === 0}
                    className="bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 px-6 py-2 rounded-lg font-bold hover:bg-teal-600 dark:hover:bg-mint-300 disabled:opacity-50 transition-colors"
                  >
                     Connect & Scan
                  </button>
               </div>
            </>
          )}

          {(step === 'connecting' || step === 'scanning') && (
             <div className="py-12 flex flex-col items-center justify-center text-center">
                <Loader2 className="w-12 h-12 text-teal-500 dark:text-mint-400 animate-spin mb-4" />
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  {step === 'connecting' ? 'Authenticating Securely...' : 'Analyzing Inbox...'}
                </h3>
             </div>
          )}

          {step === 'results' && !reviewingAsset && (
             <>
                <div className="flex justify-between items-center mb-4">
                   <div className="flex items-center gap-3">
                      <button
                        onClick={toggleSelectAll}
                        className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                          selectedAssetIndices.length === foundAssets.length && foundAssets.length > 0
                            ? 'bg-teal-500 border-teal-500 dark:bg-mint-400 dark:border-mint-400'
                            : selectedAssetIndices.length > 0
                            ? 'bg-teal-200 border-teal-500 dark:bg-mint-400/50 dark:border-mint-400'
                            : 'border-slate-300 dark:border-navy-600'
                        }`}
                      >
                        {selectedAssetIndices.length > 0 && <Check className="w-3 h-3 text-white dark:text-navy-900" />}
                      </button>
                      <h3 className="font-bold text-slate-900 dark:text-white">
                        {selectedAssetIndices.length > 0 
                          ? `${selectedAssetIndices.length} of ${foundAssets.length} Selected`
                          : `Found ${foundAssets.length} Potential Assets`}
                      </h3>
                   </div>
                </div>
                <div className="bg-slate-50 dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-navy-700 max-h-60 overflow-y-auto mb-6">
                   {foundAssets.map((asset, idx) => {
                      const isSelected = selectedAssetIndices.includes(idx);
                      return (
                        <div key={idx} className={`p-4 border-b border-slate-200 dark:border-navy-700 last:border-0 flex items-center gap-3 hover:bg-slate-100 dark:hover:bg-navy-800 transition-colors ${isSelected ? 'bg-teal-50 dark:bg-mint-400/5' : ''}`}>
                           <button
                             onClick={() => toggleAssetSelection(idx)}
                             className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
                               isSelected 
                                 ? 'bg-teal-500 border-teal-500 dark:bg-mint-400 dark:border-mint-400' 
                                 : 'border-slate-300 dark:border-navy-600 hover:border-teal-400 dark:hover:border-mint-400'
                             }`}
                           >
                             {isSelected && <Check className="w-3 h-3 text-white dark:text-navy-900" />}
                           </button>
                           <div className="w-10 h-10 rounded bg-white dark:bg-navy-800 flex items-center justify-center border border-slate-200 dark:border-navy-600 shrink-0">
                              {asset.source === 'Gmail' ? <Mail className="w-5 h-5 text-red-500" /> : <CloudRain className="w-5 h-5 text-blue-500" />}
                           </div>
                           <div className="min-w-0 flex-1">
                              <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{asset.name}</p>
                              <p className="text-xs text-slate-500 dark:text-gray-500 truncate">{asset.snippet}</p>
                           </div>
                           <button 
                             onClick={() => setReviewingAsset({ asset, idx })}
                             className="px-3 py-1.5 text-xs font-bold text-teal-600 dark:text-mint-400 bg-teal-50 dark:bg-mint-400/10 rounded border border-teal-200 dark:border-mint-400/20 shrink-0"
                           >
                             Review
                           </button>
                        </div>
                      );
                   })}
                </div>
                <button 
                  onClick={handleImport}
                  disabled={selectedAssetIndices.length === 0}
                  className="w-full bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 py-3 rounded-lg font-bold hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                   {selectedAssetIndices.length > 0 
                     ? `Verify & Import ${selectedAssetIndices.length} Selected Asset${selectedAssetIndices.length > 1 ? 's' : ''}`
                     : 'Select Assets to Import'}
                </button>
             </>
          )}

          {step === 'results' && reviewingAsset && (
             <div className="animate-in slide-in-from-right-4 duration-300">
               <div className="flex items-center gap-2 mb-4">
                 <button onClick={() => setReviewingAsset(null)} className="p-1 hover:bg-slate-100 dark:hover:bg-navy-700 rounded">
                   <ChevronLeft className="w-5 h-5 text-slate-500" />
                 </button>
                 <h3 className="font-bold text-slate-900 dark:text-white">Review Asset</h3>
               </div>
               <div className="bg-slate-50 dark:bg-navy-900 p-4 rounded-lg border border-slate-200 dark:border-navy-700 mb-4">
                  <p className="text-xs uppercase font-bold text-slate-400 dark:text-gray-500 mb-1">Source Content</p>
                  <p className="text-sm italic text-slate-600 dark:text-gray-300">"{reviewingAsset.asset.snippet}"</p>
               </div>
               <div className="space-y-4 mb-6">
                  <div>
                     <label className="text-xs uppercase font-bold text-slate-500 dark:text-gray-500 mb-1 block">Name</label>
                     <input 
                        value={reviewingAsset.asset.name}
                        onChange={(e) => setReviewingAsset({...reviewingAsset, asset: {...reviewingAsset.asset, name: e.target.value}})}
                        className="w-full p-2 rounded border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white"
                     />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                     <div>
                        <label className="text-xs uppercase font-bold text-slate-500 dark:text-gray-500 mb-1 block">Category</label>
                        <select 
                           value={reviewingAsset.asset.category}
                           onChange={(e) => setReviewingAsset({...reviewingAsset, asset: {...reviewingAsset.asset, category: e.target.value}})}
                           className="w-full p-2 rounded border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white"
                        >
                           {Object.keys(CATEGORY_LABELS).map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                     </div>
                     <div>
                        <label className="text-xs uppercase font-bold text-slate-500 dark:text-gray-500 mb-1 block">Value</label>
                        <input 
                           value={reviewingAsset.asset.value}
                           onChange={(e) => setReviewingAsset({...reviewingAsset, asset: {...reviewingAsset.asset, value: e.target.value}})}
                           className="w-full p-2 rounded border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white"
                        />
                     </div>
                  </div>
               </div>
               <button 
                  onClick={() => updateAsset(reviewingAsset.idx, reviewingAsset.asset)}
                  className="w-full bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 py-3 rounded-lg font-bold hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors"
               >
                  Confirm Changes
               </button>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

// 4. Audit Log Modal
const AuditLogModal = ({ isOpen, onClose, logs }: { isOpen: boolean, onClose: () => void, logs: AuditLogEntry[] }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<AuditLogEntry['type'] | 'all'>('all');

  const logTypeFilters: { value: AuditLogEntry['type'] | 'all'; label: string; icon: React.ReactNode; color: string }[] = [
    { value: 'all', label: 'All', icon: null, color: 'bg-slate-100 dark:bg-navy-700 text-slate-700 dark:text-gray-300' },
    { value: 'security', label: 'Security', icon: <Lock className="w-3 h-3" />, color: 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400' },
    { value: 'creation', label: 'Creation', icon: <Plus className="w-3 h-3" />, color: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400' },
    { value: 'info', label: 'Info', icon: <CheckCircle className="w-3 h-3" />, color: 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400' },
    { value: 'warning', label: 'Warning', icon: <AlertCircle className="w-3 h-3" />, color: 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400' },
    { value: 'bulk_action', label: 'Bulk', icon: <Folder className="w-3 h-3" />, color: 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400' },
  ];

  const filteredLogs = logs.filter(log => {
    const matchesSearch = searchQuery === '' || 
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'all' || log.type === activeFilter;
    return matchesSearch && matchesFilter;
  });

  useEffect(() => {
    if (!isOpen) {
      setSearchQuery('');
      setActiveFilter('all');
    }
  }, [isOpen]);

  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-navy-800 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden h-[80vh] flex flex-col border border-slate-200 dark:border-navy-600">
        <div className="p-4 border-b border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-900">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-bold flex items-center gap-2 text-slate-900 dark:text-white"><Activity className="w-5 h-5 text-teal-600 dark:text-mint-400"/> System Audit Log</h3>
            <button onClick={onClose}><X className="w-5 h-5 text-slate-500 dark:text-gray-400 hover:text-red-500"/></button>
          </div>
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search actions or details..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-teal-500 outline-none"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:text-gray-500 dark:hover:text-gray-300"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {logTypeFilters.map(filter => (
              <button
                key={filter.value}
                onClick={() => setActiveFilter(filter.value)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  activeFilter === filter.value 
                    ? filter.color + ' ring-2 ring-offset-1 ring-teal-500 dark:ring-mint-400 dark:ring-offset-navy-900'
                    : 'bg-slate-100 dark:bg-navy-700 text-slate-500 dark:text-gray-400 hover:bg-slate-200 dark:hover:bg-navy-600'
                }`}
              >
                {filter.icon}
                {filter.label}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-0">
           {logs.length === 0 ? (
             <div className="flex flex-col items-center justify-center h-full opacity-50 text-slate-500 dark:text-gray-400">
               <ShieldCheck className="w-12 h-12 mb-2"/>
               <p>No activity recorded yet.</p>
             </div>
           ) : filteredLogs.length === 0 ? (
             <div className="flex flex-col items-center justify-center h-full opacity-50 text-slate-500 dark:text-gray-400">
               <SearchX className="w-12 h-12 mb-2"/>
               <p>No matching log entries found.</p>
               <button 
                 onClick={() => { setSearchQuery(''); setActiveFilter('all'); }}
                 className="mt-2 text-sm text-teal-600 dark:text-mint-400 hover:underline"
               >
                 Clear filters
               </button>
             </div>
           ) : (
             <div className="w-full">
                <div className="bg-slate-50 dark:bg-navy-900 sticky top-0 grid grid-cols-12 text-xs uppercase font-bold text-slate-500 dark:text-gray-400 border-b border-slate-200 dark:border-navy-700">
                    <div className="col-span-3 p-3">Date/Time</div>
                    <div className="col-span-3 p-3">Action</div>
                    <div className="col-span-6 p-3">Details</div>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-navy-700">
                  {filteredLogs.map(log => (
                    <div key={log.id} className="grid grid-cols-12 hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
                      <div className="col-span-3 p-3 font-mono text-xs text-slate-500 dark:text-gray-500 flex flex-col justify-center">
                        <span>{new Date(log.timestamp).toLocaleDateString('en-CA')}</span>
                        <span className="text-slate-400 dark:text-gray-600">{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}</span>
                      </div>
                      <div className="col-span-3 p-3 font-medium flex items-center gap-2 text-slate-800 dark:text-gray-200 text-sm">
                        {log.type === 'security' && <Lock className="w-3 h-3 text-red-500"/>}
                        {log.type === 'creation' && <Plus className="w-3 h-3 text-teal-500"/>}
                        {log.type === 'info' && <CheckCircle className="w-3 h-3 text-blue-500"/>}
                        {log.type === 'warning' && <AlertCircle className="w-3 h-3 text-amber-500"/>}
                        {log.type === 'bulk_action' && <Folder className="w-3 h-3 text-purple-500"/>}
                        <span className="truncate">{log.action}</span>
                      </div>
                      <div className="col-span-6 p-3 text-sm text-slate-600 dark:text-gray-400 truncate flex items-center">
                         {log.details}
                      </div>
                    </div>
                  ))}
                </div>
             </div>
           )}
        </div>
        {filteredLogs.length > 0 && (
          <div className="p-3 border-t border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-900 text-xs text-slate-500 dark:text-gray-400 text-center">
            Showing {filteredLogs.length} of {logs.length} entries
          </div>
        )}
      </div>
    </div>
  )
};

// 5. Settings Modal (for Profile/Key Actions)
const SettingsModal = ({ 
  isOpen, 
  onClose, 
  onRotateKey, 
  onUpdateProfile 
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onRotateKey: () => void,
  onUpdateProfile: () => void
}) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-navy-800 w-full max-w-lg rounded-xl shadow-2xl p-6 border border-slate-200 dark:border-navy-600">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2"><Settings className="w-6 h-6"/> Settings</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-slate-500 dark:text-gray-400"/></button>
        </div>
        
        <div className="space-y-6">
          <div className="bg-slate-50 dark:bg-navy-900 p-4 rounded-lg border border-slate-200 dark:border-navy-700">
            <h3 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2"><User className="w-4 h-4"/> Profile Management</h3>
            <p className="text-sm text-slate-500 dark:text-gray-400 mb-4">Update your contact info and notification preferences.</p>
            <button 
              onClick={onUpdateProfile}
              className="px-4 py-2 bg-white dark:bg-navy-800 border border-slate-300 dark:border-navy-600 rounded text-sm font-bold text-slate-700 dark:text-gray-300 hover:bg-slate-50 dark:hover:bg-navy-700 w-full"
            >
              Update Profile Information
            </button>
          </div>

          <div className="bg-red-50 dark:bg-red-900/10 p-4 rounded-lg border border-red-100 dark:border-red-900/20">
            <h3 className="font-bold text-red-900 dark:text-red-400 mb-2 flex items-center gap-2"><Key className="w-4 h-4"/> Security Zone</h3>
            <p className="text-sm text-red-700 dark:text-red-300 mb-4">Rotate your master encryption key. This will re-encrypt all asset headers.</p>
            <button 
              onClick={onRotateKey}
              className="px-4 py-2 bg-red-600 text-white rounded text-sm font-bold hover:bg-red-700 w-full flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4"/> Rotate Master Key
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Avatar Icon Component
const AvatarIcon = ({ iconName, className }: { iconName: string; className?: string }) => {
  const icons: Record<string, React.ReactNode> = {
    user: <User className={className} />,
    shield: <Shield className={className} />,
    key: <Key className={className} />,
    star: <Star className={className} />,
    heart: <Heart className={className} />,
    check: <Check className={className} />,
  };
  return <>{icons[iconName] || <User className={className} />}</>;
};

// Profile Edit Modal
const ProfileEditModal = ({
  isOpen,
  onClose,
  profile,
  onSave,
  showToast
}: {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onSave: (profile: UserProfile) => void;
  showToast: (message: string, type: Toast['type']) => void;
}) => {
  const [formData, setFormData] = useState<UserProfile>(profile);
  const [saving, setSaving] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setFormData(profile);
      setShowAvatarPicker(false);
    }
  }, [isOpen, profile]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const response = await fetch(`/api/profile/${encodeURIComponent(formData.email)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        const savedProfile = await response.json();
        onSave(savedProfile);
        showToast('Profile updated successfully', 'success');
        onClose();
      } else {
        showToast('Failed to save profile', 'error');
      }
    } catch (error) {
      console.error('Error saving profile:', error);
      showToast('Failed to save profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      showToast('Avatar must be less than 2MB', 'error');
      return;
    }

    if (!file.type.startsWith('image/')) {
      showToast('Please upload an image file', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setFormData({
        ...formData,
        avatar: { type: 'upload', value: reader.result as string }
      });
      setShowAvatarPicker(false);
    };
    reader.readAsDataURL(file);
  };

  const selectTemplateAvatar = (templateId: string) => {
    setFormData({
      ...formData,
      avatar: { type: 'template', value: templateId }
    });
    setShowAvatarPicker(false);
  };

  const removeAvatar = () => {
    setFormData({
      ...formData,
      avatar: { type: 'none', value: '' }
    });
    setShowAvatarPicker(false);
  };

  const renderCurrentAvatar = () => {
    if (formData.avatar.type === 'upload' && formData.avatar.value) {
      return (
        <img 
          src={formData.avatar.value} 
          alt="Profile" 
          className="w-full h-full object-cover"
        />
      );
    }
    
    if (formData.avatar.type === 'template') {
      const template = TEMPLATE_AVATARS.find(t => t.id === formData.avatar.value);
      if (template) {
        return (
          <div className={`w-full h-full bg-gradient-to-br ${template.color} flex items-center justify-center`}>
            <AvatarIcon iconName={template.icon} className="w-10 h-10 text-white" />
          </div>
        );
      }
    }
    
    return (
      <div className="w-full h-full bg-slate-200 dark:bg-navy-700 flex items-center justify-center">
        <User className="w-10 h-10 text-slate-400 dark:text-gray-500" />
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 dark:bg-navy-900/90 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-navy-800 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden border border-slate-200 dark:border-navy-600">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-700 to-slate-800 dark:from-navy-700 dark:to-navy-800 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <User className="w-6 h-6" />
              <div>
                <h2 className="text-xl font-bold leading-none">Edit Profile</h2>
                <p className="text-xs opacity-75 mt-1">Manage your account settings</p>
              </div>
            </div>
            <button onClick={onClose}><X className="w-5 h-5" /></button>
          </div>
        </div>

        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {/* Avatar Section */}
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white dark:border-navy-700 shadow-lg">
                {renderCurrentAvatar()}
              </div>
              <button 
                onClick={() => setShowAvatarPicker(!showAvatarPicker)}
                className="absolute bottom-0 right-0 p-2 bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 rounded-full shadow-lg hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            
            {showAvatarPicker && (
              <div className="w-full bg-slate-50 dark:bg-navy-900 rounded-lg p-4 border border-slate-200 dark:border-navy-700 animate-in fade-in duration-200">
                <p className="text-sm font-medium text-slate-700 dark:text-gray-300 mb-3">Choose an avatar</p>
                
                {/* Template Avatars */}
                <div className="grid grid-cols-6 gap-2 mb-4">
                  {TEMPLATE_AVATARS.map(template => (
                    <button
                      key={template.id}
                      onClick={() => selectTemplateAvatar(template.id)}
                      className={`w-12 h-12 rounded-full bg-gradient-to-br ${template.color} flex items-center justify-center transition-all hover:scale-110 ${formData.avatar.type === 'template' && formData.avatar.value === template.id ? 'ring-2 ring-offset-2 ring-teal-500 dark:ring-mint-400' : ''}`}
                    >
                      <AvatarIcon iconName={template.icon} className="w-6 h-6 text-white" />
                    </button>
                  ))}
                </div>
                
                <div className="flex gap-2">
                  <label className="flex-1 cursor-pointer">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleAvatarUpload}
                    />
                    <span className="flex items-center justify-center gap-2 px-4 py-2 bg-white dark:bg-navy-800 border border-slate-300 dark:border-navy-600 rounded-lg text-sm font-medium text-slate-700 dark:text-gray-300 hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
                      <Upload className="w-4 h-4" /> Upload Photo
                    </span>
                  </label>
                  {formData.avatar.type !== 'none' && (
                    <button
                      onClick={removeAvatar}
                      className="px-4 py-2 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-lg text-sm font-medium hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Identity Section */}
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wide mb-4 flex items-center gap-2">
                <User className="w-4 h-4" /> Identity
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Name</label>
                  <input 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Plan</label>
                  <select 
                    value={formData.plan}
                    onChange={(e) => setFormData({...formData, plan: e.target.value as UserProfile['plan']})}
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-white dark:bg-navy-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                  >
                    <option value="Free">Free</option>
                    <option value="Sovereign">Sovereign</option>
                    <option value="Legacy">Legacy</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-500 dark:text-gray-400 uppercase mb-1">Email (Google Sign-On)</label>
                  <input 
                    value={formData.email}
                    disabled
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-navy-600 bg-slate-100 dark:bg-navy-900 text-slate-500 dark:text-gray-400 cursor-not-allowed"
                  />
                  <p className="text-xs text-slate-400 dark:text-gray-500 mt-1">Email is linked to your Google account and cannot be changed</p>
                </div>
              </div>
            </div>

            {/* Security Section */}
            <div>
              <h3 className="text-sm font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wide mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4" /> Security
              </h3>
              <div className="space-y-3">
                <label className="flex items-center justify-between p-4 bg-slate-50 dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-navy-700 cursor-pointer hover:border-slate-300 dark:hover:border-navy-600 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                      <Smartphone className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <span className="block font-medium text-slate-800 dark:text-white">Multi-Factor Authentication</span>
                      <span className="text-xs text-slate-500 dark:text-gray-400">Add an extra layer of security</span>
                    </div>
                  </div>
                  <div 
                    onClick={() => setFormData({...formData, mfaEnabled: !formData.mfaEnabled})}
                    className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${formData.mfaEnabled ? 'bg-teal-500 dark:bg-mint-400' : 'bg-slate-300 dark:bg-navy-600'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${formData.mfaEnabled ? 'left-7' : 'left-1'}`}></div>
                  </div>
                </label>

                <label className="flex items-center justify-between p-4 bg-slate-50 dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-navy-700 cursor-pointer hover:border-slate-300 dark:hover:border-navy-600 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                      <Fingerprint className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <span className="block font-medium text-slate-800 dark:text-white">Biometric Login</span>
                      <span className="text-xs text-slate-500 dark:text-gray-400">Use fingerprint or face recognition</span>
                    </div>
                  </div>
                  <div 
                    onClick={() => setFormData({...formData, biometricEnabled: !formData.biometricEnabled})}
                    className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${formData.biometricEnabled ? 'bg-teal-500 dark:bg-mint-400' : 'bg-slate-300 dark:bg-navy-600'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${formData.biometricEnabled ? 'left-7' : 'left-1'}`}></div>
                  </div>
                </label>
              </div>
            </div>

            {/* Notifications Section */}
            <div>
              <h3 className="text-sm font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wide mb-4 flex items-center gap-2">
                <Bell className="w-4 h-4" /> Notifications
              </h3>
              <div className="space-y-3">
                <label className="flex items-center justify-between p-4 bg-slate-50 dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-navy-700 cursor-pointer hover:border-slate-300 dark:hover:border-navy-600 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                      <Mail className="w-5 h-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <span className="block font-medium text-slate-800 dark:text-white">Email Notifications</span>
                      <span className="text-xs text-slate-500 dark:text-gray-400">Receive updates via email</span>
                    </div>
                  </div>
                  <div 
                    onClick={() => setFormData({...formData, notifications: {...formData.notifications, email: !formData.notifications.email}})}
                    className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${formData.notifications.email ? 'bg-teal-500 dark:bg-mint-400' : 'bg-slate-300 dark:bg-navy-600'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${formData.notifications.email ? 'left-7' : 'left-1'}`}></div>
                  </div>
                </label>

                <label className="flex items-center justify-between p-4 bg-slate-50 dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-navy-700 cursor-pointer hover:border-slate-300 dark:hover:border-navy-600 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                      <Bell className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                    </div>
                    <div>
                      <span className="block font-medium text-slate-800 dark:text-white">Push Notifications</span>
                      <span className="text-xs text-slate-500 dark:text-gray-400">Receive push alerts on your device</span>
                    </div>
                  </div>
                  <div 
                    onClick={() => setFormData({...formData, notifications: {...formData.notifications, push: !formData.notifications.push}})}
                    className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${formData.notifications.push ? 'bg-teal-500 dark:bg-mint-400' : 'bg-slate-300 dark:bg-navy-600'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${formData.notifications.push ? 'left-7' : 'left-1'}`}></div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-900 flex justify-end gap-3">
          <button 
            onClick={onClose} 
            className="px-6 py-3 rounded-lg font-bold text-slate-500 hover:text-slate-800 dark:text-gray-400 dark:hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            disabled={saving}
            className="px-8 py-3 rounded-lg font-bold bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 hover:bg-teal-600 dark:hover:bg-mint-300 transition-all shadow-lg disabled:opacity-50 flex items-center gap-2"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

// Portfolio Summary Generator for AI Context
const generatePortfolioSummary = (assets: Asset[], profile: UserProfile): string => {
  if (assets.length === 0) {
    return 'The user has no assets stored yet.';
  }

  const categoryBreakdown: Record<string, { count: number; items: string[] }> = {};
  let totalEstimatedValue = 0;
  
  assets.forEach(asset => {
    if (!categoryBreakdown[asset.category]) {
      categoryBreakdown[asset.category] = { count: 0, items: [] };
    }
    categoryBreakdown[asset.category].count++;
    categoryBreakdown[asset.category].items.push(asset.name);
    
    const numericValue = parseFloat(asset.value?.replace(/[^0-9.-]/g, '') || '0');
    if (!isNaN(numericValue)) {
      totalEstimatedValue += numericValue;
    }
  });

  let summary = `USER PORTFOLIO SUMMARY:\n`;
  summary += `- Total Assets: ${assets.length}\n`;
  summary += `- Estimated Total Value: $${totalEstimatedValue.toLocaleString()}\n`;
  summary += `- User Plan: ${profile.plan}\n`;
  summary += `- User Name: ${profile.name || 'Not set'}\n\n`;
  summary += `BREAKDOWN BY CATEGORY:\n`;
  
  Object.entries(categoryBreakdown).forEach(([category, data]) => {
    summary += `\n${category} (${data.count} items):\n`;
    data.items.slice(0, 5).forEach(item => {
      summary += `  - ${item}\n`;
    });
    if (data.items.length > 5) {
      summary += `  - ...and ${data.items.length - 5} more\n`;
    }
  });

  summary += `\nDETAILED ASSET LIST (up to 20 most recent):\n`;
  assets.slice(0, 20).forEach((asset, idx) => {
    summary += `${idx + 1}. ${asset.name} (${asset.category}/${asset.type}) - Value: ${asset.value || 'Not specified'}`;
    if (asset.expiryDate) summary += ` - Expires: ${asset.expiryDate}`;
    summary += `\n`;
  });
  
  if (assets.length > 20) {
    summary += `...and ${assets.length - 20} more assets.\n`;
  }

  return summary;
};

// Help Center Panel Component
const HelpCenterPanel = ({
  isOpen,
  onClose,
  context,
  userPlan,
  assets,
  profile,
}: {
  isOpen: boolean;
  onClose: () => void;
  context: HelpContext;
  userPlan: string;
  assets: Asset[];
  profile: UserProfile;
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const contextInfo = HELP_CONTEXTS[context];

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const toggleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Voice input is not supported in this browser. Please use Chrome or Edge.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(prev => prev + (prev ? ' ' : '') + transcript);
      inputRef.current?.focus();
    };

    recognition.start();
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (messageText: string) => {
    if (!messageText.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: generateId(),
      role: 'user',
      content: messageText.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      
      const portfolioSummary = generatePortfolioSummary(assets, profile);
      
      const systemPrompt = `You are an intelligent AI assistant for breadcrumX, a secure digital asset management application. You have full access to the user's portfolio data and can answer questions about their assets, provide insights, and help them use the app effectively.

=== CURRENT CONTEXT ===
Screen: ${contextInfo.title}
Description: ${contextInfo.description}

=== USER PROFILE ===
Name: ${profile.name || 'Not set'}
Email: ${profile.email}
Plan: ${profile.plan}
MFA Enabled: ${profile.mfaEnabled ? 'Yes' : 'No'}
Biometric Login: ${profile.biometricEnabled ? 'Yes' : 'No'}

=== USER'S PORTFOLIO DATA ===
${portfolioSummary}

=== APP FEATURES & FAQ ===
About breadcrumX:
- Secure vault for managing financial, physical, digital, medical, legal, and personal assets
- End-to-end encryption for all data
- AI-powered asset discovery and data extraction from documents/photos
- Audit logging for security tracking
- Three plans: Free (basic), Sovereign (premium features), Legacy (enterprise/family)

Asset Categories:
- Financial: Bank accounts, investments, stocks, bonds, retirement accounts, insurance policies
- Physical: Real estate, vehicles, jewelry, collectibles, artwork, valuable possessions
- Digital: Cryptocurrency, NFTs, domain names, subscriptions, online accounts
- Medical: Health records, prescriptions, insurance cards, medical history
- Legal: Contracts, wills, trusts, deeds, power of attorney, legal agreements
- Personal: Personal documents, photos, sentimental items, miscellaneous

Key Features:
- Add Asset: Click "+ Add New Asset" or use AI to extract info from photos/documents
- Auto-Discovery: AI scans connected accounts to find and catalog assets automatically
- Bulk Actions: Select multiple assets using checkboxes to move or delete at once
- File Attachments: Attach receipts, documents, or photos to any asset (up to 10MB each)
- Edit Assets: Click any asset card to edit details, change category, or delete
- Search: Use the search bar to find assets by name or type
- Master Key Rotation: Re-encrypt all data with a new key (Settings > Security Zone)
- MFA & Biometric: Enable extra security in Settings > Profile

=== YOUR CAPABILITIES ===
1. Answer questions about the user's specific assets and portfolio
2. Provide insights like "What's my most valuable category?" or "Show me expiring items"
3. Help users navigate and use app features
4. Explain how to perform specific tasks
5. Offer suggestions for organizing their assets
6. Answer general questions about asset management

=== GUIDELINES ===
- When asked about user data, reference their actual assets from the portfolio summary above
- Be conversational, helpful, and concise (2-4 sentences for simple questions, more for complex)
- Use the user's name if they've set one
- For questions about unavailable features, explain the upgrade path
- If asked something you can't determine from the data, say so honestly
- Format responses with line breaks for readability
- Never reveal technical implementation details or sensitive data patterns`;

      const conversationContext = messages.length > 0 
        ? '\n\nPrevious conversation:\n' + messages.map(m => 
            `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`
          ).join('\n') + '\n\n'
        : '';

      const fullPrompt = `${conversationContext}User question: ${messageText}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: fullPrompt,
        config: {
          systemInstruction: systemPrompt,
        },
      });

      const assistantMessage: ChatMessage = {
        id: generateId(),
        role: 'assistant',
        content: response.text || 'I apologize, but I couldn\'t generate a response. Please try again.',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
      trackEvent('help_chat', context, { question: messageText.substring(0, 100) });
    } catch (error: any) {
      console.error('AI Help Error:', error);
      console.error('Error details:', JSON.stringify(error, null, 2));
      console.error('API Key present:', !!process.env.GEMINI_API_KEY);
      console.error('API Key length:', process.env.GEMINI_API_KEY?.length || 0);
      
      let errorContent = 'I\'m having trouble connecting right now. Please try again in a moment, or contact support if the issue persists.';
      if (error?.status === 400) {
        errorContent = 'There was an issue with the AI request. This might be a configuration problem.';
      } else if (error?.status === 401 || error?.status === 403) {
        errorContent = 'API key authentication failed. Please check your Gemini API key.';
      }
      
      const errorMessage: ChatMessage = {
        id: generateId(),
        role: 'assistant',
        content: errorContent,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputValue);
  };

  const handleSuggestionClick = (suggestion: string) => {
    sendMessage(suggestion);
  };

  const clearChat = () => {
    setMessages([]);
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      <div className="fixed bottom-20 right-4 z-50 w-96 max-w-[calc(100vw-2rem)] bg-white dark:bg-navy-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-navy-600 overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-500 to-teal-600 dark:from-teal-600 dark:to-teal-700 p-4 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm">AI Help Assistant</h3>
                <p className="text-xs opacity-80">{contextInfo.description}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="h-80 overflow-y-auto p-4 space-y-4 bg-slate-50 dark:bg-navy-900">
          {messages.length === 0 ? (
            <div className="space-y-4">
              <div className="text-center py-4">
                <div className="inline-flex p-3 bg-teal-100 dark:bg-teal-900/30 rounded-full mb-3">
                  <Sparkles className="w-6 h-6 text-teal-600 dark:text-teal-400" />
                </div>
                <p className="text-sm text-slate-600 dark:text-gray-300 font-medium">How can I help you today?</p>
                <p className="text-xs text-slate-400 dark:text-gray-500 mt-1">Ask anything about breadcrumX</p>
              </div>
              
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-400 dark:text-gray-500 uppercase tracking-wide flex items-center gap-1">
                  <Lightbulb className="w-3 h-3" /> Suggested Questions
                </p>
                {contextInfo.suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="w-full text-left px-3 py-2 bg-white dark:bg-navy-800 rounded-lg border border-slate-200 dark:border-navy-600 text-sm text-slate-700 dark:text-gray-300 hover:border-teal-400 dark:hover:border-mint-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-all flex items-center gap-2 group"
                  >
                    <Zap className="w-4 h-4 text-slate-400 group-hover:text-teal-500 dark:group-hover:text-mint-400 transition-colors" />
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] px-4 py-2 rounded-2xl ${
                      message.role === 'user'
                        ? 'bg-teal-500 dark:bg-teal-600 text-white rounded-br-md'
                        : 'bg-white dark:bg-navy-800 text-slate-700 dark:text-gray-200 border border-slate-200 dark:border-navy-600 rounded-bl-md'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    <p className={`text-xs mt-1 ${message.role === 'user' ? 'text-teal-100' : 'text-slate-400 dark:text-gray-500'}`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white dark:bg-navy-800 px-4 py-3 rounded-2xl rounded-bl-md border border-slate-200 dark:border-navy-600">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-teal-500" />
                      <span className="text-sm text-slate-500 dark:text-gray-400">Thinking...</span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Input Area */}
        <div className="p-3 border-t border-slate-200 dark:border-navy-700 bg-white dark:bg-navy-800">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <div className="flex-1 relative">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask a question..."
                className="w-full px-4 py-2 pr-10 bg-slate-100 dark:bg-navy-900 border border-slate-200 dark:border-navy-600 rounded-full text-sm text-slate-700 dark:text-gray-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 dark:focus:ring-mint-400"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={toggleVoiceInput}
                disabled={isLoading}
                className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full transition-all ${
                  isListening 
                    ? 'bg-red-500 text-white animate-pulse' 
                    : 'text-slate-400 hover:text-teal-500 dark:hover:text-mint-400 hover:bg-slate-200 dark:hover:bg-navy-700'
                }`}
                title={isListening ? 'Stop listening' : 'Voice input'}
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>
            <button
              type="submit"
              disabled={!inputValue.trim() || isLoading}
              className="p-2 bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 rounded-full hover:bg-teal-600 dark:hover:bg-mint-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          {messages.length > 0 && (
            <button
              onClick={clearChat}
              className="mt-2 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-gray-300 transition-colors"
            >
              Clear conversation
            </button>
          )}
        </div>
      </div>
    </>
  );
};

// Floating Help Button Component
const FloatingHelpButton = ({
  onClick,
  isOpen,
}: {
  onClick: () => void;
  isOpen: boolean;
}) => {
  return (
    <button
      onClick={onClick}
      className={`fixed bottom-4 right-4 z-50 p-4 rounded-full shadow-lg transition-all duration-300 ${
        isOpen
          ? 'bg-slate-600 dark:bg-slate-700 rotate-45'
          : 'bg-gradient-to-r from-teal-500 to-teal-600 dark:from-teal-500 dark:to-teal-600 hover:shadow-xl hover:scale-105'
      }`}
    >
      {isOpen ? (
        <X className="w-6 h-6 text-white" />
      ) : (
        <HelpCircle className="w-6 h-6 text-white" />
      )}
    </button>
  );
};

// Toast Notification Component
const ToastContainer = ({ toasts, removeToast }: { toasts: Toast[], removeToast: (id: string) => void }) => {
  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2">
      {toasts.map(toast => (
        <div
          key={toast.id}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg border animate-in slide-in-from-right duration-300 ${
            toast.type === 'error' ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200' :
            toast.type === 'success' ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-800 dark:text-green-200' :
            toast.type === 'warning' ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800 text-yellow-800 dark:text-yellow-200' :
            'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-200'
          }`}
        >
          {toast.type === 'error' && <AlertCircle className="w-5 h-5 flex-shrink-0" />}
          {toast.type === 'success' && <CheckCircle className="w-5 h-5 flex-shrink-0" />}
          {toast.type === 'warning' && <AlertCircle className="w-5 h-5 flex-shrink-0" />}
          {toast.type === 'info' && <AlertCircle className="w-5 h-5 flex-shrink-0" />}
          <span className="text-sm font-medium">{toast.message}</span>
          <button onClick={() => removeToast(toast.id)} className="ml-2 hover:opacity-70">
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};

// Sortable Asset Card Component for drag-and-drop
const SortableAssetCard = ({ 
  asset, 
  isSelected, 
  selectionMode, 
  onSelect, 
  onEdit, 
  onDelete 
}: { 
  asset: Asset;
  isSelected: boolean;
  selectionMode: boolean;
  onSelect: (id: string) => void;
  onEdit: (asset: Asset) => void;
  onDelete: (id: string) => void;
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: asset.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 50 : 'auto',
  };

  return (
    <div 
      ref={setNodeRef}
      style={style}
      onClick={() => onEdit(asset)}
      className={`group bg-white dark:bg-navy-800 border rounded-xl p-5 hover:shadow-xl transition-all duration-300 relative overflow-hidden cursor-pointer ${isSelected ? 'border-teal-500 dark:border-mint-400 shadow-md ring-1 ring-teal-500 dark:ring-mint-400 bg-teal-50/50 dark:bg-mint-900/10' : 'border-slate-200 dark:border-navy-700 hover:border-teal-300 dark:hover:border-mint-400/50'}`}
    >
      <div className={`absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-teal-400 to-teal-600 dark:from-mint-300 dark:to-mint-500 transition-opacity ${isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}></div>
      
      {/* Drag Handle */}
      <div 
        {...attributes}
        {...listeners}
        className="absolute top-4 right-4 z-20 cursor-grab active:cursor-grabbing text-slate-300 dark:text-navy-600 hover:text-slate-500 dark:hover:text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={(e) => e.stopPropagation()}
      >
        <GripVertical className="w-5 h-5" />
      </div>
      
      {/* Selection Checkbox */}
      <div 
        className={`absolute top-4 left-4 z-20 transition-all duration-200 ${selectionMode || isSelected ? 'opacity-100 scale-100' : 'opacity-0 scale-90 group-hover:opacity-100 group-hover:scale-100'}`}
        onClick={(e) => { e.stopPropagation(); onSelect(asset.id); }}
      >
        <div className={`w-5 h-5 rounded border flex items-center justify-center cursor-pointer ${isSelected ? 'bg-teal-500 border-teal-500 text-white' : 'bg-white dark:bg-navy-900 border-slate-300 dark:border-slate-500'}`}>
          {isSelected && <Check className="w-3 h-3" />}
        </div>
      </div>

      <div className="flex justify-between items-start mb-4 pl-8 pr-6">
        <div className="p-2 bg-slate-50 dark:bg-navy-900 rounded-lg group-hover:bg-teal-50 dark:group-hover:bg-mint-400/10 transition-colors">
          {asset.category === 'Financial' && <CreditCard className="w-6 h-6 text-teal-600 dark:text-mint-400" />}
          {asset.category === 'Physical' && <Watch className="w-6 h-6 text-teal-600 dark:text-mint-400" />}
          {asset.category === 'Digital' && <HardDrive className="w-6 h-6 text-teal-600 dark:text-mint-400" />}
          {asset.category === 'Medical' && <Activity className="w-6 h-6 text-teal-600 dark:text-mint-400" />}
          {asset.category === 'Legal' && <Scale className="w-6 h-6 text-teal-600 dark:text-mint-400" />}
          {asset.category === 'Personal' && <Fingerprint className="w-6 h-6 text-teal-600 dark:text-mint-400" />}
        </div>
        {!selectionMode && (
          <button onClick={(e) => { e.stopPropagation(); onDelete(asset.id); }} className="text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
      <h3 className="font-bold text-slate-900 dark:text-white mb-1 truncate">{asset.name}</h3>
      <p className="text-xs text-slate-500 dark:text-gray-400 uppercase tracking-wide mb-4">{asset.type}</p>
      
      <div className="space-y-2">
        {asset.value && (
          <div className="flex justify-between text-sm">
            <span className="text-slate-500 dark:text-gray-500">Value</span>
            <span className="font-mono font-medium text-slate-700 dark:text-gray-300">{formatCurrencyValue(asset.value)}</span>
          </div>
        )}
      </div>
      
      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-navy-700 flex items-center justify-between text-xs text-slate-400 dark:text-gray-500">
        <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Encrypted</span>
        <span>{new Date(asset.lastUpdated!).toLocaleDateString()}</span>
      </div>
    </div>
  );
};

// API Data Adapters - normalize data between API and frontend
const adaptAssetFromApi = (apiAsset: any): Asset => ({
  id: apiAsset.assetId,
  name: apiAsset.name,
  category: apiAsset.category as CategoryType,
  type: apiAsset.type,
  value: apiAsset.value || '',
  region: apiAsset.region as Region,
  expiryDate: apiAsset.expiryDate || '',
  policyNumber: apiAsset.policyNumber || '',
  encryptedData: apiAsset.encryptedPayload || '',
  lastUpdated: apiAsset.lastUpdated,
  sortOrder: apiAsset.sortOrder || 0,
});

const adaptAssetToApi = (asset: Asset | Omit<Asset, 'id'>, assetId?: string) => ({
  assetId: assetId || (asset as Asset).id,
  name: asset.name,
  category: asset.category,
  type: asset.type,
  value: asset.value || '',
  region: asset.region,
  expiryDate: asset.expiryDate || '',
  policyNumber: asset.policyNumber || '',
  encryptedPayload: asset.encryptedData || '',
  sortOrder: (asset as Asset).sortOrder || 0,
});

// 6. Main Application Wrapper
const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [theme, setTheme] = useState<Theme>('light');
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = (message: string, type: Toast['type'] = 'info') => {
    const id = generateId();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };
  
  // Dashboard State
  const [activeCategory, setActiveCategory] = useState<CategoryType | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAssetEntryOpen, setAssetEntryOpen] = useState(false);
  const [isAutoDiscoveryOpen, setAutoDiscoveryOpen] = useState(false);
  const [isAuditOpen, setAuditOpen] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [isProfileEditOpen, setProfileEditOpen] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [isHelpCenterOpen, setHelpCenterOpen] = useState(false);

  // Derive help context based on current app state
  const getHelpContext = (): HelpContext => {
    if (isAssetEntryOpen) return 'asset-entry';
    if (isAutoDiscoveryOpen) return 'auto-discovery';
    if (isSettingsOpen || isProfileEditOpen) return 'settings';
    if (isAuditOpen) return 'audit';
    if (activeCategory !== 'All') return 'category';
    return 'dashboard';
  };

  // Bulk Action State
  const [selectedAssetIds, setSelectedAssetIds] = useState<Set<string>>(new Set());
  const [isMoveMenuOpen, setIsMoveMenuOpen] = useState(false);

  // Load assets from API on mount
  useEffect(() => {
    const loadAssets = async () => {
      try {
        const response = await fetch('/api/assets');
        if (!response.ok) {
          throw new Error(`Server error: ${response.status}`);
        }
        const data = await response.json();
        const mappedAssets = data.map(adaptAssetFromApi);
        setAssets(mappedAssets);
      } catch (error) {
        console.error('Failed to load assets:', error);
        showToast('Failed to load assets. Please refresh the page.', 'error');
      } finally {
        setIsLoading(false);
      }
    };
    loadAssets();
  }, []);

  // Load user profile from API on mount
  useEffect(() => {
    const loadProfile = async () => {
      try {
        const response = await fetch(`/api/profile/${encodeURIComponent(DEFAULT_PROFILE.email)}`);
        if (response.ok) {
          const data = await response.json();
          setUserProfile(data);
        }
      } catch (error) {
        console.error('Failed to load profile:', error);
      }
    };
    loadProfile();
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.classList.toggle('dark');
  };

  const addLog = (action: string, details: string, type: 'info' | 'warning' | 'security' | 'creation' | 'bulk_action' = 'info') => {
    const newLog: AuditLogEntry = {
      id: generateId(),
      timestamp: new Date().toISOString(),
      action,
      details,
      type
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const handleLogin = (pin: string) => {
    setIsAuthenticated(true);
    addLog('LOGIN_SUCCESS', 'User accessed vault via PIN', 'security');
    trackEvent('login', undefined, { method: 'pin' });
  };

  const handleSaveAsset = async (newAssetData: Omit<Asset, 'id'>) => {
    const assetId = generateId();
    try {
      const response = await fetch('/api/assets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(adaptAssetToApi(newAssetData, assetId)),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Failed to save asset (${response.status})`);
      }
      const savedAsset = await response.json();
      const asset = adaptAssetFromApi(savedAsset);
      setAssets(prev => [asset, ...prev]);
      addLog('ASSET_CREATED', `Added '${asset.name}' to ${asset.category}`, 'creation');
      showToast(`Asset "${asset.name}" saved successfully`, 'success');
      trackEvent('asset_created', asset.category);
    } catch (error) {
      console.error('Failed to save asset:', error);
      showToast(error instanceof Error ? error.message : 'Failed to save asset. Please try again.', 'error');
      trackEvent('asset_create_error');
    }
  };

  const handleImportAssets = async (newAssets: Omit<Asset, 'id'>[]) => {
    try {
      const assetsToCreate = newAssets.map(a => adaptAssetToApi(a, generateId()));
      
      const response = await fetch('/api/assets/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assets: assetsToCreate }),
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Failed to import assets (${response.status})`);
      }
      const savedAssets = await response.json();
      const adaptedAssets = savedAssets.map(adaptAssetFromApi);
      setAssets(prev => [...adaptedAssets, ...prev]);
      addLog('AUTO_DISCOVERY', `Imported ${newAssets.length} assets from Gmail/Drive`, 'creation');
      showToast(`Successfully imported ${newAssets.length} assets`, 'success');
      trackEvent('assets_imported', undefined, { count: newAssets.length });
    } catch (error) {
      console.error('Failed to import assets:', error);
      showToast(error instanceof Error ? error.message : 'Failed to import assets. Please try again.', 'error');
      trackEvent('assets_import_error');
    }
  };

  const handleDeleteAsset = async (id: string) => {
    const asset = assets.find(a => a.id === id);
    if (asset) {
      try {
        const response = await fetch(`/api/assets/${id}`, { method: 'DELETE' });
        
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `Failed to delete asset (${response.status})`);
        }
        
        if (editingAsset?.id === id) {
          setEditingAsset(null);
        }
        
        setAssets(prev => prev.filter(a => a.id !== id));
        addLog('ASSET_DELETED', `Removed '${asset.name}' permanently`, 'warning');
        showToast(`Asset "${asset.name}" deleted`, 'success');
        trackEvent('asset_deleted', asset.category);
        
        if (selectedAssetIds.has(id)) {
          const newSet = new Set(selectedAssetIds);
          newSet.delete(id);
          setSelectedAssetIds(newSet);
        }
      } catch (error) {
        console.error('Failed to delete asset:', error);
        showToast(error instanceof Error ? error.message : 'Failed to delete asset. Please try again.', 'error');
        trackEvent('asset_delete_error');
      }
    }
  };

  const handleUpdateAsset = async (updatedAsset: Asset) => {
    const oldAsset = assets.find(a => a.id === updatedAsset.id);
    try {
      const response = await fetch(`/api/assets/${updatedAsset.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(adaptAssetToApi(updatedAsset)),
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Failed to update asset (${response.status})`);
      }
      
      const savedAsset = await response.json();
      const asset = adaptAssetFromApi(savedAsset);
      setAssets(prev => prev.map(a => a.id === asset.id ? asset : a));
      
      if (oldAsset && oldAsset.category !== asset.category) {
        addLog('ASSET_MOVED', `Moved '${asset.name}' from ${oldAsset.category} to ${asset.category}`, 'info');
        showToast(`Asset moved to ${asset.category}`, 'success');
        trackEvent('asset_moved', asset.category);
      } else {
        addLog('ASSET_UPDATED', `Updated '${asset.name}' details`, 'info');
        showToast(`Asset "${asset.name}" updated`, 'success');
        trackEvent('asset_updated', asset.category);
      }
      setEditingAsset(null);
    } catch (error) {
      console.error('Failed to update asset:', error);
      showToast(error instanceof Error ? error.message : 'Failed to update asset. Please try again.', 'error');
      trackEvent('asset_update_error');
    }
  };

  const handleRotateKey = () => {
    addLog('KEY_ROTATION', 'Master encryption key rotated by user', 'security');
    setSettingsOpen(false);
  };

  const handleUpdateProfile = () => {
    setSettingsOpen(false);
    setProfileEditOpen(true);
  };

  const handleProfileSave = (updatedProfile: UserProfile) => {
    setUserProfile(updatedProfile);
    addLog('PROFILE_UPDATE', 'User updated profile settings', 'info');
    trackEvent('profile_updated');
  };

  // --- Bulk Actions Handlers ---
  const toggleSelection = (id: string) => {
    const newSet = new Set(selectedAssetIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedAssetIds(newSet);
  };

  const clearSelection = () => {
    setSelectedAssetIds(new Set());
    setIsMoveMenuOpen(false);
  };

  const handleBulkDelete = async () => {
    if (window.confirm(`Are you sure you want to delete ${selectedAssetIds.size} assets? This cannot be undone.`)) {
      const count = selectedAssetIds.size;
      try {
        const results = await Promise.all(
          Array.from(selectedAssetIds).map(async id => {
            const response = await fetch(`/api/assets/${id}`, { method: 'DELETE' });
            return { id, ok: response.ok };
          })
        );
        
        const failed = results.filter(r => !r.ok);
        const succeeded = results.filter(r => r.ok);
        
        if (editingAsset && selectedAssetIds.has(editingAsset.id)) {
          setEditingAsset(null);
        }
        
        const succeededIds = new Set(succeeded.map(r => r.id));
        setAssets(prev => prev.filter(a => !succeededIds.has(a.id)));
        
        if (failed.length > 0) {
          showToast(`Deleted ${succeeded.length} assets, ${failed.length} failed`, 'warning');
        } else {
          showToast(`Successfully deleted ${count} assets`, 'success');
        }
        
        addLog('BULK_DELETE', `Deleted ${succeeded.length} assets`, 'bulk_action');
        trackEvent('bulk_delete', undefined, { count: succeeded.length });
        clearSelection();
      } catch (error) {
        console.error('Failed to bulk delete assets:', error);
        showToast('Failed to delete assets. Please try again.', 'error');
        trackEvent('bulk_delete_error');
      }
    }
  };

  const handleBulkMove = async (targetCategory: CategoryType) => {
    const count = selectedAssetIds.size;
    try {
      const updatePromises = Array.from(selectedAssetIds).map(async id => {
        const asset = assets.find(a => a.id === id);
        if (asset) {
          const updatedAsset = { ...asset, category: targetCategory };
          const response = await fetch(`/api/assets/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(adaptAssetToApi(updatedAsset)),
          });
          if (response.ok) {
            return { success: true, data: await response.json() };
          }
          return { success: false, id };
        }
        return null;
      });
      
      const results = await Promise.all(updatePromises);
      const succeeded = results.filter(r => r?.success).map(r => adaptAssetFromApi(r!.data));
      const failed = results.filter(r => r && !r.success);
      
      setAssets(prev => prev.map(a => {
        const updated = succeeded.find(u => u.id === a.id);
        return updated || a;
      }));
      
      if (failed.length > 0) {
        showToast(`Moved ${succeeded.length} assets, ${failed.length} failed`, 'warning');
      } else {
        showToast(`Successfully moved ${count} assets to ${targetCategory}`, 'success');
      }
      
      addLog('BULK_MOVE', `Moved ${succeeded.length} assets to ${targetCategory}`, 'bulk_action');
      trackEvent('bulk_move', targetCategory, { count: succeeded.length });
      clearSelection();
    } catch (error) {
      console.error('Failed to bulk move assets:', error);
      showToast('Failed to move assets. Please try again.', 'error');
      trackEvent('bulk_move_error');
    }
  };

  const filteredAssets = assets
    .filter(asset => {
      const matchesCategory = activeCategory === 'All' || asset.category === activeCategory;
      const matchesSearch = searchQuery === '' || asset.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    })
    .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));

  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      const oldIndex = filteredAssets.findIndex(a => a.id === active.id);
      const newIndex = filteredAssets.findIndex(a => a.id === over.id);
      
      if (oldIndex !== -1 && newIndex !== -1) {
        const reorderedAssets = arrayMove([...filteredAssets], oldIndex, newIndex);
        
        // Update sort orders
        const updatedAssets: Asset[] = reorderedAssets.map((asset, index) => ({
          ...asset,
          sortOrder: index,
        }));
        
        // Update local state immediately for responsive UI
        setAssets(prev => {
          const newAssets = [...prev];
          updatedAssets.forEach(updated => {
            const idx = newAssets.findIndex(a => a.id === updated.id);
            if (idx !== -1) {
              newAssets[idx] = updated;
            }
          });
          return newAssets;
        });
        
        // Persist to database
        try {
          await fetch('/api/assets/reorder', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              updates: updatedAssets.map(a => ({ assetId: a.id, sortOrder: a.sortOrder })),
            }),
          });
        } catch (error) {
          console.error('Failed to save order:', error);
        }
      }
    }
  };

  if (!isAuthenticated) {
    return <AuthFlow onComplete={handleLogin} theme={theme} toggleTheme={toggleTheme} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-900 transition-colors duration-300 pb-20">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white dark:bg-navy-800 border-r border-slate-200 dark:border-navy-700 hidden md:flex flex-col z-10">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
             <Shield className="w-8 h-8 text-teal-600 dark:text-mint-400" />
             <span className="font-bold text-xl text-slate-800 dark:text-white tracking-tight">breadcrumX</span>
          </div>
          
          <button 
             onClick={() => setAutoDiscoveryOpen(true)}
             className="w-full bg-gradient-to-r from-teal-500 to-teal-600 dark:from-mint-400 dark:to-mint-500 text-white dark:text-navy-900 font-bold py-3 px-4 rounded-xl shadow-lg shadow-teal-500/20 hover:shadow-teal-500/30 transition-all flex items-center justify-center gap-2 mb-6"
          >
             <Sparkles className="w-4 h-4" />
             Auto-Discovery
          </button>

          <nav className="space-y-1">
             {(['All', 'Financial', 'Physical', 'Digital', 'Medical', 'Legal', 'Personal'] as const).map(cat => (
               <button
                 key={cat}
                 onClick={() => setActiveCategory(cat)}
                 className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeCategory === cat ? 'bg-slate-100 dark:bg-navy-700 text-teal-600 dark:text-mint-400' : 'text-slate-600 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-navy-700/50'}`}
               >
                 <span>{cat}</span>
                 {cat !== 'All' && <span className="bg-slate-200 dark:bg-navy-600 text-xs px-2 py-0.5 rounded-full">{assets.filter(a => a.category === cat).length}</span>}
               </button>
             ))}
          </nav>
        </div>
        
        <div className="mt-auto p-4 border-t border-slate-200 dark:border-navy-700 space-y-2">
           <button onClick={() => setSettingsOpen(true)} className="flex items-center gap-3 w-full px-4 py-2 text-sm font-medium text-slate-600 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
              <Settings className="w-4 h-4" /> Settings
           </button>
           <button onClick={() => setAuditOpen(true)} className="flex items-center gap-3 w-full px-4 py-2 text-sm font-medium text-slate-600 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-50 dark:hover:bg-navy-700 transition-colors">
              <History className="w-4 h-4" /> Audit Log
           </button>
           <div className="pt-4 flex justify-between items-center">
              <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
              <button onClick={() => setIsAuthenticated(false)} className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 p-2 rounded-full transition-colors"><LogOut className="w-5 h-5"/></button>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="md:ml-64 min-h-screen p-8">
         <header className="flex justify-between items-center mb-8">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{activeCategory === 'All' ? 'Vault Overview' : CATEGORY_LABELS[activeCategory]}</h1>
            <div className="flex items-center gap-4">
               <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Search secure assets..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 rounded-lg bg-white dark:bg-navy-800 border border-slate-200 dark:border-navy-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 dark:focus:ring-mint-400 outline-none w-64 shadow-sm"
                  />
               </div>
               <button 
                 onClick={() => setAssetEntryOpen(true)}
                 className="flex items-center gap-2 bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 px-4 py-2 rounded-lg font-bold hover:bg-teal-600 dark:hover:bg-mint-300 transition-all shadow-md hover:shadow-lg"
               >
                 <Plus className="w-4 h-4" /> Add New Asset
               </button>
            </div>
         </header>

         {filteredAssets.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 animate-in fade-in duration-500">
               <div className="relative w-24 h-24 mb-6">
                 <div className="absolute inset-0 bg-teal-100 dark:bg-mint-400/20 rounded-full animate-ping opacity-20"></div>
                 <div className="absolute inset-0 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-navy-800 dark:to-navy-700 rounded-full flex items-center justify-center shadow-inner">
                    {searchQuery ? <SearchX className="w-10 h-10 text-slate-400" /> : <FolderOpen className="w-10 h-10 text-teal-600 dark:text-mint-400" />}
                 </div>
               </div>
               <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                 {searchQuery ? 'No matching assets found' : `No ${activeCategory === 'All' ? '' : activeCategory} assets yet`}
               </h3>
               <p className="text-slate-500 dark:text-gray-400 max-w-sm text-center mb-8">
                 {searchQuery ? "Try adjusting your search terms or category filter." : "Your vault is secure but empty. Start by adding your first asset."}
               </p>
               {!searchQuery && (
                 <button 
                   onClick={() => setAssetEntryOpen(true)}
                   className="flex items-center gap-2 bg-teal-500 dark:bg-mint-400 text-white dark:text-navy-900 px-6 py-3 rounded-lg font-bold hover:bg-teal-600 dark:hover:bg-mint-300 transition-all shadow-lg hover:shadow-teal-500/20"
                 >
                   <Plus className="w-5 h-5" /> Add New Asset
                 </button>
               )}
            </div>
         ) : (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={filteredAssets.map(a => a.id)}
                strategy={rectSortingStrategy}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredAssets.map(asset => (
                    <SortableAssetCard
                      key={asset.id}
                      asset={asset}
                      isSelected={selectedAssetIds.has(asset.id)}
                      selectionMode={selectedAssetIds.size > 0}
                      onSelect={toggleSelection}
                      onEdit={setEditingAsset}
                      onDelete={handleDeleteAsset}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
         )}
      </main>

      {/* Bulk Action Bar - Fixed Bottom */}
      {selectedAssetIds.size > 0 && (
         <div className="fixed bottom-6 left-0 right-0 z-40 flex justify-center animate-in slide-in-from-bottom-10 fade-in duration-300">
            <div className="bg-slate-900 dark:bg-white text-white dark:text-navy-900 rounded-full shadow-2xl px-6 py-3 flex items-center gap-4 border border-slate-700 dark:border-slate-200">
               <div className="font-bold text-sm whitespace-nowrap">
                  {selectedAssetIds.size} Selected
               </div>
               <div className="h-6 w-px bg-slate-700 dark:bg-slate-200"></div>
               
               {/* Move Action */}
               <div className="relative">
                  <button 
                     onClick={() => setIsMoveMenuOpen(!isMoveMenuOpen)}
                     className="flex items-center gap-2 text-sm font-bold hover:text-teal-400 dark:hover:text-teal-600 transition-colors"
                  >
                     <FolderInput className="w-4 h-4" /> Move
                  </button>
                  {isMoveMenuOpen && (
                     <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-48 bg-white dark:bg-navy-800 rounded-lg shadow-xl border border-slate-200 dark:border-navy-600 overflow-hidden py-1">
                        {Object.keys(CATEGORY_LABELS).map(cat => (
                           <button
                              key={cat}
                              onClick={() => handleBulkMove(cat as CategoryType)}
                              className="w-full text-left px-4 py-2 text-sm hover:bg-slate-100 dark:hover:bg-navy-700 text-slate-700 dark:text-gray-200"
                           >
                              {cat}
                           </button>
                        ))}
                     </div>
                  )}
               </div>

               {/* Delete Action */}
               <button 
                  onClick={handleBulkDelete}
                  className="flex items-center gap-2 text-sm font-bold text-red-400 hover:text-red-300 dark:text-red-600 dark:hover:text-red-500 transition-colors"
               >
                  <Trash2 className="w-4 h-4" /> Delete
               </button>

               <div className="h-6 w-px bg-slate-700 dark:bg-slate-200"></div>
               
               {/* Close */}
               <button onClick={clearSelection} className="hover:bg-slate-800 dark:hover:bg-slate-200 rounded-full p-1 transition-colors">
                  <X className="w-5 h-5" />
               </button>
            </div>
         </div>
      )}

      {/* Modals */}
      <AssetEntryModal 
        isOpen={isAssetEntryOpen} 
        onClose={() => setAssetEntryOpen(false)} 
        onSave={handleSaveAsset}
        defaultCategory={activeCategory !== 'All' ? activeCategory : undefined}
      />

      <EditAssetModal
        asset={editingAsset}
        isOpen={editingAsset !== null}
        onClose={() => setEditingAsset(null)}
        onSave={handleUpdateAsset}
        onDelete={handleDeleteAsset}
        showToast={showToast}
      />
      
      <AutoDiscoveryModal 
        isOpen={isAutoDiscoveryOpen} 
        onClose={() => setAutoDiscoveryOpen(false)}
        onImport={handleImportAssets}
      />

      <AuditLogModal
        isOpen={isAuditOpen}
        onClose={() => setAuditOpen(false)}
        logs={auditLogs}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setSettingsOpen(false)}
        onRotateKey={handleRotateKey}
        onUpdateProfile={handleUpdateProfile}
      />

      <ProfileEditModal
        isOpen={isProfileEditOpen}
        onClose={() => setProfileEditOpen(false)}
        profile={userProfile}
        onSave={handleProfileSave}
        showToast={showToast}
      />

      {/* AI Help Center */}
      {isAuthenticated && (
        <>
          <FloatingHelpButton 
            onClick={() => setHelpCenterOpen(!isHelpCenterOpen)} 
            isOpen={isHelpCenterOpen} 
          />
          <HelpCenterPanel
            isOpen={isHelpCenterOpen}
            onClose={() => setHelpCenterOpen(false)}
            context={getHelpContext()}
            userPlan={userProfile.plan}
            assets={assets}
            profile={userProfile}
          />
        </>
      )}

      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(<App />);
}