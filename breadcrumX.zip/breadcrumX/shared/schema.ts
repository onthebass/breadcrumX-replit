import { pgTable, text, serial, timestamp, varchar, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const apiMetrics = pgTable("api_metrics", {
  id: serial("id").primaryKey(),
  endpoint: varchar("endpoint", { length: 100 }).notNull(),
  method: varchar("method", { length: 10 }).notNull(),
  statusCode: integer("status_code").notNull(),
  responseTime: real("response_time").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const usageEvents = pgTable("usage_events", {
  id: serial("id").primaryKey(),
  eventType: varchar("event_type", { length: 50 }).notNull(),
  category: varchar("category", { length: 50 }),
  count: integer("count").default(1),
  metadata: text("metadata"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  assetId: varchar("asset_id", { length: 50 }).notNull().unique(),
  name: text("name").notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  type: text("type").notNull(),
  value: text("value"),
  region: varchar("region", { length: 10 }),
  expiryDate: text("expiry_date"),
  policyNumber: text("policy_number"),
  encryptedPayload: text("encrypted_payload"),
  sortOrder: integer("sort_order").default(0),
  lastUpdated: timestamp("last_updated").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const attachments = pgTable("attachments", {
  id: serial("id").primaryKey(),
  attachmentId: varchar("attachment_id", { length: 50 }).notNull().unique(),
  assetId: varchar("asset_id", { length: 50 }).notNull(),
  fileName: text("file_name").notNull(),
  fileType: varchar("file_type", { length: 100 }),
  fileSize: integer("file_size"),
  fileData: text("file_data"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default(''),
  email: varchar("email", { length: 255 }).notNull().unique(),
  plan: varchar("plan", { length: 20 }).notNull().default('Free'),
  mfaEnabled: integer("mfa_enabled").notNull().default(0),
  biometricEnabled: integer("biometric_enabled").notNull().default(0),
  notifyEmail: integer("notify_email").notNull().default(1),
  notifyPush: integer("notify_push").notNull().default(0),
  avatarType: varchar("avatar_type", { length: 20 }).notNull().default('none'),
  avatarValue: text("avatar_value"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  logId: varchar("log_id", { length: 50 }).notNull().unique(),
  timestamp: timestamp("timestamp").defaultNow(),
  action: text("action").notNull(),
  details: text("details").notNull(),
  type: varchar("type", { length: 20 }).notNull(),
});

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = typeof assets.$inferInsert;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;
export type ApiMetric = typeof apiMetrics.$inferSelect;
export type InsertApiMetric = typeof apiMetrics.$inferInsert;
export type UsageEvent = typeof usageEvents.$inferSelect;
export type InsertUsageEvent = typeof usageEvents.$inferInsert;
export type Attachment = typeof attachments.$inferSelect;
export type InsertAttachment = typeof attachments.$inferInsert;
export type UserProfileDB = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;
