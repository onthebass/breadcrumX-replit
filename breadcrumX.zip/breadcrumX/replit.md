# breadcrumX - The Invisible Fortress

## Overview

breadcrumX is a secure digital asset management application built with React, Vite, and Google's Gemini AI. The application provides a fortress-like security system for managing financial, physical, digital, medical, legal, and personal assets with end-to-end encryption.

**Current State**: Application fully configured with PostgreSQL database for persistent storage. Frontend accessible via port 5000, backend API on port 3001.

## Recent Changes (November 25, 2025)

### AI Help Center (Latest - Data-Aware LLM)
- Full-featured AI assistant powered by Gemini 2.5 Flash with access to user's portfolio
- Floating help button appears on all screens (bottom-right)
- Help panel slides up with chat interface
- Voice input support via Web Speech API (microphone button)
- Automatically detects user's current screen/feature:
  - Dashboard, Category View, Asset Entry, Auto-Discovery, Settings, Audit Log
  - Adapts suggestions and AI prompts based on context
- Data-Aware Capabilities:
  - Answers questions about user's specific assets ("How many assets do I have?")
  - Provides portfolio insights ("What's my most valuable category?")
  - Shows user profile information ("What plan am I on?")
  - Lists assets by category or type
  - Portfolio summary generator aggregates asset data for AI context
- Features:
  - Conversational AI chat with full history
  - Quick suggestion buttons for common questions
  - Context-aware system prompts with user data
  - Voice input with microphone button (Chrome/Edge)
  - Error handling with graceful fallbacks
  - Usage tracking for analytics
- Only visible when user is authenticated

### Profile Edit with Avatar Support
- Added user_profiles database table for persistent profile storage
- Backend endpoints for profile CRUD:
  - GET /api/profile/:email - Load user profile (returns defaults if none exists)
  - PUT /api/profile/:email - Create/update user profile (upsert)
- ProfileEditModal with comprehensive UI:
  - Identity section: Name input, Plan dropdown (Free/Sovereign/Legacy), disabled email field
  - Avatar picker with 6 template avatars (gradient icons) and custom upload (2MB limit)
  - Security section: MFA and biometric login toggles
  - Notifications section: Email and push notification toggles
- Settings modal updated to open ProfileEditModal
- All profile data persists to PostgreSQL database

### File Attachments Feature
- Added attachments table in database schema to store file metadata and base64 data
- Backend endpoints for attachment CRUD operations:
  - GET /api/assets/:assetId/attachments - List attachments for an asset
  - POST /api/assets/:assetId/attachments - Upload new attachment
  - GET /api/attachments/:attachmentId/download - Download attachment data
  - DELETE /api/attachments/:attachmentId - Delete an attachment
- Updated EditAssetModal with full attachment management:
  - View attached files with file type icons
  - Preview images and PDFs directly in modal
  - Download any attached file
  - Delete attachments with single click
  - Add new files (up to 10MB each)
  - File size display and proper formatting
- Supports all file types with smart preview detection

### Built-in Monitoring System
- Added privacy-focused monitoring that keeps all data within the app
- Backend middleware logs API response times and error rates
- Health check endpoint (`/api/health`) for system status
- Metrics summary endpoint (`/api/metrics/summary`) for performance insights
- Usage event tracking for key user actions (login, asset CRUD, bulk operations)
- All metrics stored in PostgreSQL (apiMetrics and usageEvents tables)
- Non-blocking frontend event tracking

### Error Handling
- Toast notification system for user feedback
- Proper error handling for all API operations
- Success/error/warning messages for all actions

### Database Integration
- Integrated PostgreSQL database with Drizzle ORM for permanent asset storage
- Created Express backend API server on port 3001 with full CRUD endpoints
- Implemented data normalization layer (adaptAssetFromApi/adaptAssetToApi) for consistent data handling
- All asset operations (create, read, update, delete, bulk) now persist to database
- Removed Policy/Ref # and Jurisdiction fields from asset entry and edit forms
- Assets survive page reloads and application restarts

### Initial Setup
- Imported project from GitHub
- Configured Vite dev server to use port 5000 (required for Replit webview)
- Set up proper host configuration (0.0.0.0) for Replit proxy compatibility
- Configured HMR (Hot Module Replacement) for port 5000
- Installed Node.js 20 and all project dependencies
- Set up deployment configuration for autoscale deployment
- Configured workflow "Start application" to run development server
- Added multi-selection checkboxes to Auto-Discovery asset import flow:
  - Users can now select which discovered assets to import
  - Select All/Deselect All checkbox in header
  - Visual feedback for selected items
  - Import button shows count of selected assets
  - Assets must be explicitly selected before importing (no auto-import all)
- Added EditAssetModal for editing saved assets:
  - Click on any saved asset card to open the edit modal
  - Edit all asset properties (name, category, type, value, expiry date)
  - Move assets to different categories via dropdown
  - Delete assets with confirmation dialog
  - Proper event propagation handling for checkboxes and delete buttons
  - Modal lifecycle managed correctly (closes on delete, update, or cancel)

## Project Architecture

### Technology Stack
- **Frontend Framework**: React 19.2.0
- **Build Tool**: Vite 6.2.0
- **Language**: TypeScript 5.8.2
- **AI Integration**: Google Gemini AI (@google/genai 1.30.0)
- **UI Icons**: Lucide React
- **Styling**: Tailwind CSS (via CDN)

### Port Configuration
- **Development Server**: Port 5000 (configured for Replit webview)
- **Host**: 0.0.0.0 (allows Replit proxy access)

### Key Files
- `index.tsx`: Main application file with all components and logic (1200+ lines)
- `vite.config.ts`: Vite configuration with port 5000 and HMR settings
- `package.json`: Project dependencies and scripts
- `tsconfig.json`: TypeScript configuration
- `.env.local`: Environment variables (GEMINI_API_KEY)

### Application Features
- Secure authentication system (tester mode enabled for development)
- Multi-category asset management (Financial, Physical, Digital, Medical, Legal, Personal)
- Region-based data residency (AU/US)
- End-to-end encryption with mock crypto service
- AI-powered assistant using Google Gemini
- Dark/light theme support
- Audit logging system
- User profile management with MFA and biometric options

## Environment Setup

### Required Environment Variables
- `GEMINI_API_KEY`: Google Gemini API key for AI functionality
  - Currently set to placeholder value in `.env.local`
  - Users need to provide their own API key from [Google AI Studio](https://ai.studio/apps/)

### Setting Up Gemini API Key
1. Obtain a Gemini API key from Google AI Studio
2. Update the `GEMINI_API_KEY` in Replit's Secrets tab or in `.env.local`
3. The application will automatically load the key through Vite's environment variable system

## Development

### Running the Application
The workflow "Start application" runs `npm run dev` which:
- Starts Vite dev server on port 5000
- Enables hot module replacement
- Serves the application at `http://0.0.0.0:5000/`

### Available Scripts
- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm run preview`: Preview production build

## Deployment

Deployment is configured for Replit's autoscale deployment:
- **Build Command**: `npm run build`
- **Run Command**: `npx vite preview --port 5000 --host 0.0.0.0`
- **Deployment Type**: Autoscale (stateless web application)

## Security Notes

- The application includes mock encryption services for demonstration
- Tester access is enabled by default in the current build
- Production deployment should use real encryption and authentication
- API keys should be managed through Replit Secrets for security

## Future Enhancements

- Replace mock crypto service with real encryption
- Implement proper OAuth/MFA authentication
- Add backend API for persistent data storage
- Integrate real payment processing for subscription plans
- Implement actual biometric authentication
